var V = Object.defineProperty;
var D = (n, t, e) => t in n ? V(n, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) : n[t] = e;
var a = (n, t, e) => D(n, typeof t != "symbol" ? t + "" : t, e);
const _ = {
  id: "w95.queryViewToggle",
  // 使用插件前缀避免冲突
  command: "toggleQueryView",
  storageKey: "w95.queryViewHiddenState",
  // 使用插件前缀
  defaultShortcut: "ctrl+shift+q",
  observerOptions: {
    childList: !0,
    subtree: !0,
    attributes: !1,
    characterData: !1
  }
}, x = {
  QUERY_TABS_CONTAINER: ".orca-block-editor-query-tabs-container",
  QUERY_VIEWS: ".orca-block-editor-query-views",
  BLOCK_EDITOR: ".orca-block-editor",
  ACTIVE_BLOCK: ".orca-block-editor:focus-within"
}, K = "w95-query-view-toggle-styles", z = "w95.queryViewToggle", P = {
  hiddenIds: {},
  styleElement: null,
  observer: null,
  isInitialized: !1
}, c = {
  retryInterval: 300,
  maxRetries: 30,
  toolbarSelector: ".orca-block-editor-sidetools",
  targetPanelSelector: ".orca-panel.active"
}, G = {
  buttonId: "w95-heading-number-toggle-btn",
  numberClass: "w95-auto-generated-number",
  toolbarSelector: c.toolbarSelector,
  retryInterval: c.retryInterval,
  maxRetries: c.maxRetries,
  storageKey: "w95.headingNumberEnabled"
}, q = {
  isEnabled: !1,
  retryCount: 0,
  observer: null,
  isInitialized: !1
}, v = {
  containerSelector: ".orca-repr-tag-props",
  buttonClass: "w95-toggle-orca-btn",
  buttonContainerClass: "w95-toggle-btn-container",
  observerOptions: {
    childList: !0,
    subtree: !0,
    attributes: !1,
    characterData: !1
  }
}, W = {
  id: "w95.queryBlockRefToggle",
  buttonId: "w95-hide-specific-query-block-btn",
  toolbarSelector: c.toolbarSelector,
  targetPanelSelector: c.targetPanelSelector,
  retryInterval: c.retryInterval,
  maxRetries: c.maxRetries,
  storageKey: "w95.queryBlockRefHidden"
}, j = {
  buttonId: "w95-highlight-specific-query-block-btn",
  toolbarSelector: c.toolbarSelector,
  targetPanelSelector: c.targetPanelSelector,
  retryInterval: c.retryInterval,
  maxRetries: c.maxRetries,
  highlightColor: "var(--orca-color-primary-ultralight, rgba(22, 93, 255, 0.08))",
  storageKey: "w95.specificQueryBlockIsHighlighted"
}, U = {
  buttonId: "w95-mirror-container-toggle-btn",
  styleId: "w95-mirror-hide-style",
  toolbarSelector: c.toolbarSelector,
  targetPanelSelector: c.targetPanelSelector,
  retryInterval: c.retryInterval,
  maxRetries: c.maxRetries,
  storageKey: "w95.mirrorContainersHidden"
}, Z = {
  buttonId: "w95-list-breadcrumb-toggle-btn",
  styleId: "w95-list-breadcrumb-hide-style",
  toolbarSelector: c.toolbarSelector,
  targetPanelSelector: c.targetPanelSelector,
  retryInterval: c.retryInterval,
  maxRetries: c.maxRetries,
  storageKey: "w95.listBreadcrumbHidden"
}, Y = {
  buttonId: "w95-card-view-minimal-toggle-btn",
  styleId: "w95-card-view-minimal-style",
  toolbarSelector: c.toolbarSelector,
  targetPanelSelector: c.targetPanelSelector,
  retryInterval: c.retryInterval,
  maxRetries: c.maxRetries,
  storageKey: "w95.cardViewIsMinimal"
}, Q = {
  buttonId: "w95-card-cover-aspect-ratio-btn",
  styleId: "w95-card-cover-aspect-ratio-style",
  toolbarSelector: c.toolbarSelector,
  targetPanelSelector: c.targetPanelSelector,
  retryInterval: c.retryInterval,
  maxRetries: c.maxRetries,
  storageKey: "w95.cardCoverAspectRatioState",
  states: [
    { ratio: "11 / 16", icon: "portrait", title: "切换为16:9比例" },
    { ratio: "16 / 9", icon: "landscape", title: "禁用比例控制" },
    { ratio: "auto", icon: "disabled", title: "启用11:16比例" }
  ]
}, J = {
  buttonId: "w95-query-list-block-creation-time-toggle-btn",
  styleId: "w95-query-list-block-creation-time-style",
  targetSelector: ".orca-block.orca-container.orca-query-list-block-block",
  timeFormat: "YYYY-MM-DD HH:mm",
  retryInterval: 500,
  maxRetries: 15,
  storageKey: "w95.queryListBlockCreationTimeEnabled",
  colorSchemes: {
    light: [
      {
        name: "凌晨",
        start: 0,
        end: 6,
        textColor: "#2563eb",
        borderColor: "rgba(37, 99, 235, 0.5)",
        icon: "ti ti-moon"
      },
      {
        name: "上午",
        start: 6,
        end: 12,
        textColor: "#0369a1",
        borderColor: "rgba(3, 105, 161, 0.5)",
        icon: "ti ti-sunrise"
      },
      {
        name: "中午",
        start: 12,
        end: 14,
        textColor: "#ca8a04",
        borderColor: "rgba(202, 138, 4, 0.6)",
        icon: "ti ti-sun"
      },
      {
        name: "下午",
        start: 14,
        end: 18,
        textColor: "#c2410c",
        borderColor: "rgba(194, 65, 12, 0.6)",
        icon: "ti ti-sunset"
      },
      {
        name: "晚上",
        start: 18,
        end: 24,
        textColor: "#7c3aed",
        borderColor: "rgba(124, 58, 237, 0.5)",
        icon: "ti ti-stars"
      }
    ],
    dark: [
      {
        name: "凌晨",
        start: 0,
        end: 6,
        bgColor: "rgba(30, 41, 59, 0.6)",
        textColor: "#93c5fd",
        borderColor: "rgba(93, 188, 252, 0.35)",
        icon: "ti ti-moon"
      },
      {
        name: "上午",
        start: 6,
        end: 12,
        bgColor: "rgba(20, 70, 89, 0.45)",
        textColor: "#60a5fa",
        borderColor: "rgba(96, 165, 250, 0.4)",
        icon: "ti ti-sunrise"
      },
      {
        name: "中午",
        start: 12,
        end: 14,
        bgColor: "rgba(101, 73, 18, 0.4)",
        textColor: "#fbbf24",
        borderColor: "rgba(251, 191, 36, 0.45)",
        icon: "ti ti-sun"
      },
      {
        name: "下午",
        start: 14,
        end: 18,
        bgColor: "rgba(107, 45, 14, 0.4)",
        textColor: "#fb923c",
        borderColor: "rgba(251, 146, 60, 0.45)",
        icon: "ti ti-sunset"
      },
      {
        name: "晚上",
        start: 18,
        end: 24,
        bgColor: "rgba(55, 48, 163, 0.35)",
        textColor: "#a78bfa",
        borderColor: "rgba(167, 139, 250, 0.4)",
        icon: "ti ti-stars"
      }
    ]
  }
}, X = {
  buttonId: "w95-theme2-toggle-btn",
  styleId: "w95-theme2-style",
  toolbarSelector: c.toolbarSelector,
  retryInterval: c.retryInterval,
  maxRetries: c.maxRetries,
  storageKey: "w95.theme2Loaded",
  cssFilePath: "css/theme2.css"
}, tt = {
  buttonId: "w95-ocr-image-block-toggle-btn",
  containerSelector: ".orca-menu.orca-search-modal",
  footerSelector: ".orca-search-modal-footer",
  targetBlockSelector: ".orca-menu-item.orca-search-modal-block-item",
  photoClassSelector: ".ti-photo",
  retryInterval: 300,
  maxRetries: 30,
  storageKey: "w95.ocrImageBlockState",
  stateTextMap: {
    0: "关闭",
    1: "隐藏OCR图片块",
    2: "仅显示OCR图片块"
  },
  stateTitleMap: {
    0: "当前：关闭，点击隐藏OCR图片块",
    1: "当前：隐藏OCR图片块，点击仅显示OCR图片块",
    2: "当前：仅显示OCR图片块，点击关闭"
  }
};
class et {
  constructor() {
    a(this, "state");
    a(this, "config", _);
    a(this, "broadcastChannel", null);
    this.state = { ...P };
  }
  /**
   * 初始化插件
   */
  initialize() {
    this.state.isInitialized || (this.initState(), this.registerOrcaCommand(), this.setupCrossTabListener(), this.setupMutationObserver(), this.updateStyleElement(), this.state.isInitialized = !0, console.log("✅ W95 查询视图切换插件已初始化"));
  }
  /**
   * 销毁插件
   */
  destroy() {
    this.state.isInitialized && (this.state.styleElement && (this.state.styleElement.remove(), this.state.styleElement = null), this.state.observer && (this.state.observer.disconnect(), this.state.observer = null), this.broadcastChannel && (this.broadcastChannel.close(), this.broadcastChannel = null), this.unregisterOrcaCommand(), this.state = { ...P }, console.log("✅ W95 查询视图切换插件已销毁"));
  }
  /**
   * 获取公共 API
   */
  getAPI() {
    return {
      toggle: (t) => this.toggleView(t),
      show: (t) => this.showView(t),
      hide: (t) => this.hideView(t),
      getState: (t) => this.getViewState(t),
      destroy: () => this.destroy()
    };
  }
  /**
   * 初始化状态
   */
  initState() {
    try {
      const t = localStorage.getItem(this.config.storageKey);
      if (t) {
        const e = JSON.parse(t);
        typeof e == "object" && e !== null && !Array.isArray(e) ? this.state.hiddenIds = e : (console.warn("检测到无效的状态格式，已重置为默认值"), this.state.hiddenIds = {}, localStorage.setItem(this.config.storageKey, JSON.stringify(this.state.hiddenIds)));
      }
    } catch (t) {
      console.error("状态初始化失败，已重置:", t), this.state.hiddenIds = {}, localStorage.setItem(this.config.storageKey, JSON.stringify(this.state.hiddenIds));
    }
  }
  /**
   * 切换指定面板的查询视图显示/隐藏状态
   */
  toggleView(t) {
    if (!t) {
      console.error("缺少有效的面板ID");
      return;
    }
    this.state.hiddenIds[t] = !this.state.hiddenIds[t], this.persistState(), this.applyViewState(t), this.showFeedback(t);
  }
  /**
   * 显示指定面板的查询视图
   */
  showView(t) {
    t && (this.state.hiddenIds[t] = !1, this.persistState(), this.applyViewState(t));
  }
  /**
   * 隐藏指定面板的查询视图
   */
  hideView(t) {
    t && (this.state.hiddenIds[t] = !0, this.persistState(), this.applyViewState(t));
  }
  /**
   * 获取指定面板的状态
   */
  getViewState(t) {
    return t && this.state.hiddenIds[t] || !1;
  }
  /**
   * 持久化状态
   */
  persistState() {
    try {
      localStorage.setItem(this.config.storageKey, JSON.stringify(this.state.hiddenIds)), this.broadcastState();
    } catch (t) {
      console.error("状态保存失败:", t);
    }
  }
  /**
   * 应用视图状态
   */
  applyViewState(t) {
    this.updateStyleElement();
  }
  /**
   * 创建/更新样式元素
   */
  updateStyleElement() {
    this.state.styleElement || (this.state.styleElement = document.createElement("style"), this.state.styleElement.id = K, document.head.appendChild(this.state.styleElement));
    let t = "";
    Object.entries(this.state.hiddenIds).forEach(([e, o]) => {
      o && (t += `
          .orca-block-editor[data-block-id="${e}"] ${x.QUERY_TABS_CONTAINER},
          .orca-block-editor[data-block-id="${e}"] ${x.QUERY_VIEWS} {
            display: none !important;
          }
        `);
    }), this.state.styleElement.textContent = t;
  }
  /**
   * 显示反馈通知
   */
  showFeedback(t) {
    const e = this.state.hiddenIds[t] ? "隐藏" : "显示", o = `面板 [${t}] 查询视图已${e}`;
    console.log(o);
  }
  /**
   * 跨标签页广播状态
   */
  broadcastState() {
    if (window.BroadcastChannel) {
      const t = new BroadcastChannel(z);
      t.postMessage({
        type: "stateUpdate",
        hiddenIds: this.state.hiddenIds
      }), t.close();
    }
  }
  /**
   * 设置跨标签页监听
   */
  setupCrossTabListener() {
    window.BroadcastChannel && (this.broadcastChannel = new BroadcastChannel(z), this.broadcastChannel.addEventListener("message", (t) => {
      t.data.type === "stateUpdate" && typeof t.data.hiddenIds == "object" && (this.state.hiddenIds = t.data.hiddenIds, this.updateStyleElement());
    }));
  }
  /**
   * 设置 DOM 变化观察者
   */
  setupMutationObserver() {
    this.state.observer && this.state.observer.disconnect(), this.state.observer = new MutationObserver((t) => {
      t.some(
        (o) => Array.from(o.addedNodes).some(
          (r) => {
            var s, i;
            return ((s = r.classList) == null ? void 0 : s.contains("orca-block-editor")) || ((i = r.querySelector) == null ? void 0 : i.call(r, ".orca-block-editor"));
          }
        ) || Array.from(o.removedNodes).some(
          (r) => {
            var s;
            return (s = r.classList) == null ? void 0 : s.contains("orca-block-editor");
          }
        )
      ) && this.updateStyleElement();
    }), this.state.observer.observe(document.body, this.config.observerOptions);
  }
  /**
   * 注册 Orca 命令
   */
  registerOrcaCommand() {
    var t;
    if (!(!window.orca || !orca.commands))
      try {
        const e = `${this.config.id}.${this.config.command}`;
        typeof orca.commands.unregisterCommand == "function" && orca.commands.unregisterCommand(e), typeof orca.commands.registerCommand == "function" && orca.commands.registerCommand(
          e,
          () => {
            const o = document.querySelector(x.ACTIVE_BLOCK), r = o == null ? void 0 : o.dataset.blockId;
            r ? this.toggleView(r) : console.warn("未找到激活的面板");
          },
          "切换当前面板查询视图显示状态"
        ), typeof ((t = orca.shortcuts) == null ? void 0 : t.assign) == "function" && (orca.shortcuts.assign("", e), orca.shortcuts.assign(this.config.defaultShortcut, e));
      } catch (e) {
        console.error("Orca集成失败:", e);
      }
  }
  /**
   * 注销 Orca 命令
   */
  unregisterOrcaCommand() {
    var t;
    if (!(!window.orca || !orca.commands))
      try {
        const e = `${this.config.id}.${this.config.command}`;
        typeof orca.commands.unregisterCommand == "function" && orca.commands.unregisterCommand(e), typeof ((t = orca.shortcuts) == null ? void 0 : t.assign) == "function" && orca.shortcuts.assign("", e);
      } catch (e) {
        console.error("Orca命令注销失败:", e);
      }
  }
}
class ot {
  constructor(t) {
    a(this, "pluginName");
    this.pluginName = t;
  }
  /**
   * 保存状态数据
   */
  async saveState(t, e) {
    try {
      const o = typeof e == "string" ? e : JSON.stringify(e);
      await orca.plugins.setData(this.pluginName, t, o);
    } catch (o) {
      console.error(`[${this.pluginName}] 状态保存失败:`, o);
      try {
        localStorage.setItem(
          `${this.pluginName}.${t}`,
          typeof e == "string" ? e : JSON.stringify(e)
        );
      } catch (r) {
        console.error(`[${this.pluginName}] localStorage备用保存也失败:`, r);
      }
    }
  }
  /**
   * 读取状态数据，支持从localStorage自动迁移
   */
  async loadState(t, e = null) {
    try {
      const o = await orca.plugins.getData(this.pluginName, t);
      if (o != null)
        return this.parseValue(o, e);
      const r = `${this.pluginName}.${t}`, s = localStorage.getItem(r);
      return s !== null ? (console.log(`[${this.pluginName}] 检测到localStorage数据，正在迁移到Orca API: ${t}`), await this.saveState(t, s), localStorage.removeItem(r), this.parseValue(s, e)) : e;
    } catch (o) {
      console.error(`[${this.pluginName}] 状态读取失败:`, o);
      try {
        const r = localStorage.getItem(`${this.pluginName}.${t}`);
        return r !== null ? this.parseValue(r, e) : e;
      } catch (r) {
        return console.error(`[${this.pluginName}] localStorage备用读取也失败:`, r), e;
      }
    }
  }
  /**
   * 删除状态数据
   */
  async removeState(t) {
    try {
      await orca.plugins.removeData(this.pluginName, t), localStorage.removeItem(`${this.pluginName}.${t}`);
    } catch (e) {
      console.error(`[${this.pluginName}] 状态删除失败:`, e);
    }
  }
  /**
   * 解析存储的值
   */
  parseValue(t, e) {
    if (typeof t == "string") {
      if (t === "true") return !0;
      if (t === "false") return !1;
      if (t === "null") return null;
      if (t === "undefined") return e;
      if (!isNaN(Number(t)) && !isNaN(parseFloat(t)))
        return Number(t);
      try {
        return JSON.parse(t);
      } catch {
        return t;
      }
    }
    return t;
  }
  /**
   * 批量迁移localStorage数据到Orca API
   */
  async migrateFromLocalStorage(t) {
    console.log(`[${this.pluginName}] 开始批量迁移localStorage数据...`);
    for (const e of t)
      try {
        await this.loadState(e);
      } catch (o) {
        console.error(`[${this.pluginName}] 迁移键 ${e} 失败:`, o);
      }
    console.log(`[${this.pluginName}] localStorage数据迁移完成`);
  }
}
function $(n) {
  return new ot(n);
}
class rt {
  constructor(t, e) {
    a(this, "state");
    a(this, "config", G);
    a(this, "buttonManager", null);
    a(this, "persistenceManager", null);
    this.state = { ...q }, this.buttonManager = t || null, this.persistenceManager = e ? $(e) : null;
  }
  /**
   * 初始化插件
   */
  async initialize() {
    this.state.isInitialized || (await this.initState(), this.createButton(), this.state.isEnabled && this.applyNumbers(), this.setupToolbarObserver(), this.state.isInitialized = !0, console.log("✅ W95 标题编号切换插件已初始化"));
  }
  /**
   * 销毁插件
   */
  destroy() {
    if (!this.state.isInitialized) return;
    const t = document.getElementById(this.config.buttonId);
    t && t.remove(), this.clearNumbers(), this.state.observer && (this.state.observer.disconnect(), this.state.observer = null), this.state = { ...q }, console.log("✅ W95 标题编号切换插件已销毁");
  }
  /**
   * 获取公共 API
   */
  getAPI() {
    return {
      toggle: () => this.toggleState(),
      enable: () => this.enableNumbers(),
      disable: () => this.disableNumbers(),
      isEnabled: () => this.state.isEnabled,
      destroy: () => this.destroy()
    };
  }
  /**
   * 初始化状态
   */
  async initState() {
    try {
      if (this.persistenceManager)
        this.state.isEnabled = await this.persistenceManager.loadState("headingNumberEnabled", !1);
      else {
        const t = localStorage.getItem(this.config.storageKey);
        this.state.isEnabled = t === "true";
      }
    } catch (t) {
      console.error("[HeadingNumberToggle] 状态初始化失败:", t), this.state.isEnabled = !1;
    }
  }
  /**
   * 添加编号（核心修改：去掉末尾点号）
   */
  applyNumbers() {
    this.clearNumbers();
    let t = 0, e = 0, o = 0, r = 0;
    document.querySelectorAll(".orca-repr-heading-content").forEach((s) => {
      const i = parseInt(s.dataset.level || "0");
      if (!i || i < 1 || i > 4) return;
      switch (i) {
        case 1:
          t++, e = o = r = 0;
          break;
        case 2:
          e++, o = r = 0;
          break;
        case 3:
          o++, r = 0;
          break;
        case 4:
          r++;
          break;
      }
      let d = `${t}`;
      i >= 2 && (d += `.${e}`), i >= 3 && (d += `.${o}`), i >= 4 && (d += `.${r}`), d += " ";
      const l = document.createElement("span");
      l.className = this.config.numberClass, l.style.fontWeight = "600", l.style.opacity = "0.85", l.style.marginRight = "0.5em", l.textContent = d, s.insertBefore(l, s.firstChild);
    });
  }
  /**
   * 清除编号
   */
  clearNumbers() {
    document.querySelectorAll(`.${this.config.numberClass}`).forEach((t) => t.remove());
  }
  /**
   * 切换状态
   */
  async toggleState() {
    this.state.isEnabled = !this.state.isEnabled, this.updateButtonStyle(), this.state.isEnabled ? this.applyNumbers() : this.clearNumbers(), await this.persistState();
  }
  /**
   * 启用编号
   */
  async enableNumbers() {
    this.state.isEnabled || (this.state.isEnabled = !0, this.updateButtonStyle(), this.applyNumbers(), await this.persistState());
  }
  /**
   * 禁用编号
   */
  async disableNumbers() {
    this.state.isEnabled && (this.state.isEnabled = !1, this.updateButtonStyle(), this.clearNumbers(), await this.persistState());
  }
  /**
   * 持久化状态
   */
  async persistState() {
    try {
      this.persistenceManager ? await this.persistenceManager.saveState("headingNumberEnabled", this.state.isEnabled) : localStorage.setItem(this.config.storageKey, this.state.isEnabled.toString());
    } catch (t) {
      console.error("[HeadingNumberToggle] 状态保存失败:", t);
    }
  }
  /**
   * 创建按钮
   */
  createButton() {
    const t = document.getElementById(this.config.buttonId);
    t && t.remove();
    const e = document.createElement("button");
    if (e.id = this.config.buttonId, e.title = "标题编号（点击切换启用/关闭）", e.style.width = "24px", e.style.height = "24px", e.style.margin = "5px 8px", e.style.padding = "0", e.style.border = "none", e.style.borderRadius = "3px", e.style.backgroundColor = "transparent", e.style.cursor = "pointer", e.style.display = "flex", e.style.alignItems = "center", e.style.justifyContent = "center", e.style.transition = "all 0.2s ease", e.addEventListener("click", async () => await this.toggleState()), this.buttonManager)
      this.buttonManager.registerButton(
        this.config.buttonId,
        e,
        2,
        // 优先级：标题编号按钮
        "headingNumberToggle",
        () => {
          this.updateButtonStyle();
        }
      );
    else {
      const o = document.querySelector(this.config.toolbarSelector);
      if (o) {
        o.appendChild(e), this.state.retryCount = 0, this.state.isEnabled && (this.updateButtonStyle(), this.applyNumbers());
        return;
      }
      this.state.retryCount < this.config.maxRetries ? (this.state.retryCount++, setTimeout(() => this.createButton(), this.config.retryInterval)) : console.warn("无法添加标题编号按钮：超过最大重试次数");
    }
  }
  /**
   * 更新按钮图标
   */
  updateButtonIcon() {
    const t = document.getElementById(this.config.buttonId);
    t && (this.state.isEnabled ? t.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 2L13.09 8.26L19 7L17.74 13.74L24 15L17.74 16.26L19 23L13.09 21.74L12 28L10.91 21.74L5 23L6.26 16.26L0 15L6.26 13.74L5 7L10.91 8.26L12 2Z" fill="#666"/>
          <path d="M12 9V15" stroke="#666" stroke-width="2" stroke-linecap="round"/>
          <path d="M9 12H15" stroke="#666" stroke-width="2" stroke-linecap="round"/>
        </svg>
      ` : t.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M3 6H21V8H3V6ZM3 11H21V13H3V11ZM3 16H21V18H3V16Z" fill="#666"/>
        </svg>
      `);
  }
  /**
   * 更新按钮样式
   */
  updateButtonStyle() {
    const t = document.getElementById(this.config.buttonId);
    if (!t) return;
    this.updateButtonIcon();
    const e = t.querySelectorAll("svg path");
    this.state.isEnabled ? (t.style.backgroundColor = "var(--orca-color-primary-light, rgba(22, 93, 255, 0.15))", e.forEach((o) => o.setAttribute("fill", "var(--orca-color-primary, #165DFF)"))) : (t.style.backgroundColor = "transparent", e.forEach((o) => o.setAttribute("fill", "var(--orca-color-text-secondary, #666)")));
  }
  /**
   * 监听工具栏变化
   */
  setupToolbarObserver() {
    this.state.observer = new MutationObserver((t) => {
      const e = document.getElementById(this.config.buttonId), o = document.querySelector(this.config.toolbarSelector);
      o && (!e || !o.contains(e)) && this.createButton();
    }), this.state.observer.observe(document.body, {
      childList: !0,
      subtree: !0
    });
  }
}
class it {
  constructor() {
    a(this, "state", {
      observer: null,
      isInitialized: !1
    });
    a(this, "initializedContainers", /* @__PURE__ */ new WeakSet());
  }
  initialize() {
    this.state.isInitialized || (this.checkAndInitContainers(), this.startMutationObserver(), this.state.isInitialized = !0, console.log("✅ W95 属性折叠切换模块已初始化"));
  }
  destroy() {
    this.state.isInitialized && (this.state.observer && (this.state.observer.disconnect(), this.state.observer = null), document.querySelectorAll(`.${v.buttonContainerClass}`).forEach((t) => t.remove()), this.state.isInitialized = !1, console.log("✅ W95 属性折叠切换模块已销毁"));
  }
  getAPI() {
    return {
      refresh: () => this.checkAndInitContainers(),
      destroy: () => this.destroy()
    };
  }
  checkAndInitContainers() {
    const t = `${v.containerSelector}:not([data-w95-props-initialized])`;
    document.querySelectorAll(t).forEach((o) => {
      this.initializedContainers.has(o) || (this.init(o), this.initializedContainers.add(o), o.setAttribute("data-w95-props-initialized", "true"));
    });
  }
  startMutationObserver() {
    const t = document.body;
    this.state.observer = new MutationObserver((e) => {
      for (const o of e)
        o.addedNodes.length && o.addedNodes.forEach((r) => {
          var s, i;
          if (r.nodeType === 1) {
            const d = r;
            (s = d.matches) != null && s.call(d, v.containerSelector) && !this.initializedContainers.has(d) ? (this.init(d), this.initializedContainers.add(d), d.setAttribute("data-w95-props-initialized", "true")) : (i = d.querySelectorAll) == null || i.call(d, `${v.containerSelector}:not([data-w95-props-initialized])`).forEach((l) => {
              this.initializedContainers.has(l) || (this.init(l), this.initializedContainers.add(l), l.setAttribute("data-w95-props-initialized", "true"));
            });
          }
        });
    }), this.state.observer.observe(t, v.observerOptions);
  }
  init(t) {
    var O, A, N;
    const e = {
      display: t.style.display,
      position: t.style.position
    };
    getComputedStyle(t).position === "static" && (t.style.position = "relative");
    const o = this.getContainerId(t), r = (O = t.parentElement) == null ? void 0 : O.querySelector(`.${v.buttonClass}[data-for="${o}"]`);
    r == null || r.remove();
    const s = document.createElement("div");
    s.className = v.buttonContainerClass, s.style.cssText = `
      position: absolute;
      top: 6px;
      right: 6px;
      z-index: 9999;
      opacity: 0;
      visibility: hidden;
      transform: translateX(3px);
      transition: all 0.5s ease;
      pointer-events: auto;
    `, (A = t.parentElement) == null || A.appendChild(s);
    const i = t.getBoundingClientRect(), d = (N = t.parentElement) == null ? void 0 : N.getBoundingClientRect();
    d && (s.style.top = i.top - d.top + 6 + "px", s.style.right = d.right - i.right + 6 + "px");
    const l = document.createElement("button");
    l.className = v.buttonClass, l.title = "切换显示/隐藏", l.setAttribute("data-for", o);
    const m = `
      <svg width="8" height="5" viewBox="0 0 8 5" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M1 1L4 4L7 1" stroke="white" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    `, I = `
      <svg width="8" height="5" viewBox="0 0 8 5" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M1 4L4 1L7 4" stroke="white" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    `;
    l.innerHTML = m, l.style.cssText = `
      width: 18px;
      height: 18px;
      padding: 0;
      margin: 0;
      background: rgba(0,0,0,0.6);
      border: none;
      border-radius: 50%;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: transform 0.2s ease, opacity 0.6s ease, background 0.6s ease;
      outline: none;
      box-shadow: 0 1px 2px rgba(0,0,0,0.15);
      opacity: 1;
    `, s.appendChild(l);
    let C = !1, f = !1, B = !1;
    const b = () => {
      C ? (s.style.opacity = "1", s.style.visibility = "visible", s.style.transform = "translateX(0)", l.style.opacity = f ? "1" : "0.35", l.style.background = f ? "rgba(0,0,0,0.8)" : "rgba(0,0,0,0.6)") : B || f ? (s.style.opacity = "1", s.style.visibility = "visible", s.style.transform = "translateX(0)", l.style.opacity = "1", l.style.background = "rgba(0,0,0,0.8)") : (s.style.opacity = "0", s.style.visibility = "hidden", s.style.transform = "translateX(3px)", l.style.opacity = "1", l.style.background = "rgba(0,0,0,0.6)");
    }, y = () => {
      l.style.transform = "scale(0.9)", setTimeout(() => l.style.transform = "scale(1)", 150), C = !C, C ? (t.style.display = "none", l.innerHTML = I) : (t.style.display = e.display || "", l.innerHTML = m), b();
    };
    t.addEventListener("mouseenter", () => {
      B = !0, b();
    }), t.addEventListener("mouseleave", () => {
      B = !1, b();
    }), l.addEventListener("mouseenter", () => {
      f = !0, b();
    }), l.addEventListener("mouseleave", () => {
      f = !1, b();
    }), l.addEventListener("click", y);
    const S = new MutationObserver(() => {
      document.body.contains(t) || (s.remove(), S.disconnect(), this.initializedContainers.delete(t));
    });
    S.observe(document.body, { childList: !0, subtree: !0 }), b();
  }
  getContainerId(t) {
    return t.id || `w95-props-${Math.random().toString(36).substr(2, 9)}`;
  }
}
class st {
  constructor(t) {
    a(this, "state", {
      isHidden: !1,
      retryCount: 0,
      observer: null,
      isInitialized: !1
    });
    a(this, "config", W);
    a(this, "buttonEl", null);
    a(this, "buttonManager", null);
    this.buttonManager = t || null;
  }
  initialize() {
    this.state.isInitialized || (this.initState(), this.createButton(), this.state.isHidden && this.hideMatchingBlocks(), this.setupObserver(), this.state.isInitialized = !0, console.log("✅ W95 仅块引用隐藏切换模块已初始化"));
  }
  destroy() {
    this.state.isInitialized && (this.buttonEl && (this.buttonEl.remove(), this.buttonEl = null), this.state.observer && (this.state.observer.disconnect(), this.state.observer = null), this.showHiddenBlocks(), this.state.isInitialized = !1, console.log("✅ W95 仅块引用隐藏切换模块已销毁"));
  }
  getAPI() {
    return {
      toggle: () => this.toggleState(),
      show: () => this.showBlocks(),
      hide: () => this.hideBlocks(),
      getState: () => this.state.isHidden,
      destroy: () => this.destroy()
    };
  }
  /**
   * 初始化状态
   */
  initState() {
    try {
      const t = localStorage.getItem(this.config.storageKey);
      this.state.isHidden = t === "true";
    } catch (t) {
      console.error("状态初始化失败:", t), this.state.isHidden = !1;
    }
  }
  /**
   * 切换状态
   */
  toggleState() {
    this.state.isHidden = !this.state.isHidden, this.updateButtonStyle(), this.state.isHidden ? this.hideMatchingBlocks() : this.showHiddenBlocks(), this.saveState();
  }
  /**
   * 显示块
   */
  showBlocks() {
    this.state.isHidden && (this.state.isHidden = !1, this.updateButtonStyle(), this.showHiddenBlocks(), this.saveState());
  }
  /**
   * 隐藏块
   */
  hideBlocks() {
    this.state.isHidden || (this.state.isHidden = !0, this.updateButtonStyle(), this.hideMatchingBlocks(), this.saveState());
  }
  /**
   * 保存状态到本地存储
   */
  saveState() {
    try {
      localStorage.setItem(this.config.storageKey, this.state.isHidden.toString());
    } catch (t) {
      console.error("状态保存失败:", t);
    }
  }
  /**
   * 隐藏匹配的块
   */
  hideMatchingBlocks() {
    document.querySelectorAll(".orca-query-list-block").forEach((t) => {
      const e = t.querySelector(".orca-repr-main");
      if (e && e.classList.contains("orca-repr-main-collapsed")) return;
      const r = t.querySelector(".orca-repr-children");
      if (r && Array.from(r.childNodes).some(
        (l) => {
          var m;
          return l.nodeType === 1 || l.nodeType === 3 && ((m = l.textContent) == null ? void 0 : m.trim()) !== "";
        }
      ))
        return;
      const s = t.querySelector(".orca-repr-main-content.orca-repr-text-content");
      if (!s) return;
      const i = s.children;
      i.length === 3 && i[0].classList.contains("orca-none-selectable") && i[1].classList.contains("orca-inline") && i[1].dataset.type === "r" && i[2].classList.contains("orca-none-selectable") && (t.style.display = "none");
    });
  }
  /**
   * 显示所有隐藏的块
   */
  showHiddenBlocks() {
    document.querySelectorAll(".orca-query-list-block").forEach((t) => {
      t.style.display = "";
    });
  }
  /**
   * 创建按钮
   */
  createButton() {
    const t = document.getElementById(this.config.buttonId);
    t && t.remove();
    const e = document.createElement("button");
    if (e.id = this.config.buttonId, e.title = this.state.isHidden ? "显示所有块引用内容" : "隐藏仅块引用内容", e.style.width = "24px", e.style.height = "24px", e.style.margin = "5px 8px", e.style.padding = "0", e.style.border = "none", e.style.borderRadius = "3px", e.style.backgroundColor = "transparent", e.style.cursor = "pointer", e.style.display = "flex", e.style.alignItems = "center", e.style.justifyContent = "center", e.style.transition = "all 0.2s ease", e.addEventListener("click", () => this.toggleState()), this.buttonManager)
      this.buttonManager.registerButton(
        this.config.buttonId,
        e,
        4,
        // 优先级：块引用隐藏切换按钮
        "queryBlockRefToggle",
        () => this.updateButtonStyle()
        // 按钮添加完成后更新样式
      );
    else {
      const o = document.querySelector(this.config.targetPanelSelector);
      if (o) {
        const r = o.querySelector(this.config.toolbarSelector);
        if (r) {
          r.appendChild(e), this.buttonEl = e, this.state.retryCount = 0, this.state.isHidden && this.hideMatchingBlocks(), this.updateButtonStyle();
          return;
        }
      }
      this.state.retryCount < this.config.maxRetries ? (this.state.retryCount++, setTimeout(() => this.createButton(), this.config.retryInterval)) : console.warn('无法添加"块引用内容切换"按钮：超过最大重试次数');
    }
  }
  /**
   * 更新按钮图标
   */
  updateButtonIcon() {
    const t = document.getElementById(this.config.buttonId);
    t && (t.innerHTML = this.state.isHidden ? this.getHiddenIcon() : this.getShownIcon());
  }
  /**
   * 更新按钮样式
   */
  updateButtonStyle() {
    const t = document.getElementById(this.config.buttonId);
    if (!t) return;
    this.updateButtonIcon();
    const e = t.querySelectorAll("svg path");
    this.state.isHidden ? (t.style.backgroundColor = "var(--orca-color-primary-light, rgba(22, 93, 255, 0.15))", e.forEach((o) => o.setAttribute("stroke", "var(--orca-color-primary, #165DFF)")), t.title = "显示所有块引用内容") : (t.style.backgroundColor = "transparent", e.forEach((o) => o.setAttribute("stroke", "var(--orca-color-text-secondary, #666)")), t.title = "隐藏仅块引用内容");
  }
  /**
   * 设置观察者
   */
  setupObserver() {
    this.state.observer = new MutationObserver((t) => {
      const e = document.getElementById(this.config.buttonId), o = document.querySelector(this.config.targetPanelSelector);
      if (o) {
        const r = o.querySelector(this.config.toolbarSelector);
        r && (!e || !r.contains(e)) && this.createButton();
      } else e && e.remove();
    }), this.state.observer.observe(document.body, {
      childList: !0,
      subtree: !0,
      attributes: !0,
      attributeFilter: ["class"]
    });
  }
  getHiddenIcon() {
    return `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="3" y="3" width="18" height="18" rx="2" stroke="#666" stroke-width="2"/>
        <path d="M8 8l8 8" stroke="#666" stroke-width="2" stroke-linecap="round"/>
        <path d="M8 16l8-8" stroke="#666" stroke-width="2" stroke-linecap="round"/>
      </svg>
    `;
  }
  getShownIcon() {
    return `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="3" y="3" width="18" height="18" rx="2" stroke="#666" stroke-width="2"/>
      </svg>
    `;
  }
}
function nt(n, t, e, o, r) {
  const s = document.getElementById(n.id);
  s && s.remove();
  const i = document.createElement("button");
  return i.id = n.id, i.title = e ? t.active.title : t.inactive.title, i.style.width = n.width || "24px", i.style.height = n.height || "24px", i.style.margin = n.margin || "5px 8px", i.style.padding = n.padding || "0", i.style.border = "none", i.style.borderRadius = n.borderRadius || "3px", i.style.backgroundColor = e ? t.active.backgroundColor : t.inactive.backgroundColor, i.style.cursor = n.cursor || "pointer", i.style.display = n.display || "flex", i.style.alignItems = n.alignItems || "center", i.style.justifyContent = n.justifyContent || "center", i.style.transition = n.transition || "all 0.2s ease", i.innerHTML = o, i.addEventListener("click", r), i;
}
function at(n, t, e) {
  if (!n) return;
  const o = n.querySelectorAll("svg");
  e ? (n.style.backgroundColor = t.active.backgroundColor, o.forEach((r) => r.setAttribute("color", t.active.iconColor)), n.title = t.active.title) : (n.style.backgroundColor = t.inactive.backgroundColor, o.forEach((r) => r.setAttribute("color", t.inactive.iconColor)), n.title = t.inactive.title);
}
function lt(n, t, e) {
  const o = document.querySelector(e);
  if (o) {
    const r = o.querySelector(t);
    if (r)
      return r.appendChild(n), !0;
  }
  return !1;
}
function ct(n, t, e, o) {
  let r = 0;
  const s = () => {
    n() || (r < e ? (r++, setTimeout(s, t)) : o == null || o());
  };
  s();
}
class dt {
  constructor(t = 300, e = 30, o = ".orca-block-editor-sidetools", r = ".orca-panel.active") {
    a(this, "registeredButtons", /* @__PURE__ */ new Map());
    a(this, "isInitialized", !1);
    a(this, "retryCount", 0);
    a(this, "retryTimer", null);
    this.retryInterval = t, this.maxRetries = e, this.toolbarSelector = o, this.targetPanelSelector = r;
  }
  /**
   * 注册按钮
   */
  registerButton(t, e, o, r, s) {
    this.registeredButtons.set(t, {
      id: t,
      button: e,
      priority: o,
      pluginName: r,
      onButtonAdded: s
    }), this.isInitialized && (this.tryAddAllButtons(), s && setTimeout(s, 0));
  }
  /**
   * 注销按钮
   */
  unregisterButton(t) {
    const e = this.registeredButtons.get(t);
    e && (e.button.remove(), this.registeredButtons.delete(t));
  }
  /**
   * 初始化按钮管理器
   */
  initialize() {
    this.isInitialized || (this.isInitialized = !0, this.registeredButtons.size > 0 && this.tryAddAllButtons());
  }
  /**
   * 销毁按钮管理器
   */
  destroy() {
    this.isInitialized = !1, this.retryTimer && (clearTimeout(this.retryTimer), this.retryTimer = null), this.registeredButtons.forEach((t) => {
      t.button.remove();
    }), this.registeredButtons.clear();
  }
  /**
   * 尝试添加所有按钮到工具栏
   */
  tryAddAllButtons() {
    const t = document.querySelector(this.targetPanelSelector);
    if (!t) {
      this.scheduleRetry();
      return;
    }
    const e = t.querySelector(this.toolbarSelector);
    if (!e) {
      this.scheduleRetry();
      return;
    }
    const o = Array.from(this.registeredButtons.values()).sort((s, i) => s.priority - i.priority), r = [];
    for (const s of o)
      e.contains(s.button) || (e.appendChild(s.button), s.onButtonAdded && r.push(s.onButtonAdded));
    this.retryCount = 0, console.log("✅ 所有工具栏按钮已按顺序添加"), r.forEach((s) => {
      setTimeout(s, 0);
    });
  }
  /**
   * 安排重试
   */
  scheduleRetry() {
    if (this.retryCount >= this.maxRetries) {
      console.warn("无法添加工具栏按钮：超过最大重试次数");
      return;
    }
    this.retryCount++, this.retryTimer = window.setTimeout(() => {
      this.tryAddAllButtons();
    }, this.retryInterval);
  }
  /**
   * 获取已注册的按钮数量
   */
  getButtonCount() {
    return this.registeredButtons.size;
  }
  /**
   * 检查按钮是否已注册
   */
  hasButton(t) {
    return this.registeredButtons.has(t);
  }
}
function ht(n, t) {
  return new MutationObserver((e) => {
    const o = document.querySelector(n.targetPanelSelector);
    t(o);
  });
}
function ut(n, t, e = {
  childList: !0,
  subtree: !0,
  attributes: !0,
  attributeFilter: ["class"],
  attributeOldValue: !0
}) {
  const o = new MutationObserver((r) => {
    r.some((i) => !!(i.type === "attributes" && i.attributeName === "class" && i.target instanceof Element && i.target.classList.contains("orca-repr-main") || i.type === "childList" && i.target instanceof Element && i.target.closest(".orca-repr-children"))) && t();
  });
  return n && o.observe(n, e), o;
}
function gt(n, t = document.body, e = {
  childList: !0,
  subtree: !0,
  attributes: !0,
  attributeFilter: ["class"]
}) {
  n.observe(t, e);
}
function k(n) {
  n && n.disconnect();
}
class mt {
  constructor(t) {
    a(this, "state", {
      isHighlighted: !1,
      retryCount: 0,
      mainObserver: null,
      blockObserver: null,
      highlightedBlocks: /* @__PURE__ */ new Set(),
      isInitialized: !1
    });
    a(this, "config", j);
    a(this, "buttonEl", null);
    a(this, "buttonManager", null);
    this.buttonManager = t || null;
  }
  initialize() {
    this.state.isInitialized || (this.initState(), this.createButton(), this.state.isHighlighted && this.highlightMatchingBlocks(), this.setupMainObserver(), this.state.isInitialized = !0, console.log("✅ W95 仅块引用背景色高亮切换模块已初始化"));
  }
  destroy() {
    this.state.isInitialized && (this.buttonEl && (this.buttonEl.remove(), this.buttonEl = null), k(this.state.mainObserver), this.state.mainObserver = null, k(this.state.blockObserver), this.state.blockObserver = null, this.state.highlightedBlocks.forEach((t) => {
      t.style.removeProperty("background-color");
    }), this.state.highlightedBlocks.clear(), this.state.isInitialized = !1, console.log("✅ W95 仅块引用背景色高亮切换模块已销毁"));
  }
  getAPI() {
    return {
      toggle: () => this.toggleHighlightState(),
      enable: () => this.enableHighlight(),
      disable: () => this.disableHighlight(),
      getState: () => this.state.isHighlighted,
      destroy: () => this.destroy()
    };
  }
  /**
   * 初始化状态
   */
  initState() {
    try {
      const t = localStorage.getItem(this.config.storageKey);
      this.state.isHighlighted = t === "true";
    } catch (t) {
      console.error("状态初始化失败:", t), this.state.isHighlighted = !1;
    }
  }
  /**
   * 核心判断逻辑：仅对符合条件的区块操作
   */
  highlightMatchingBlocks() {
    const t = /* @__PURE__ */ new Set();
    document.querySelectorAll(".orca-query-list-block").forEach((e) => {
      const o = e.querySelector(".orca-repr-main");
      if (o && o.classList.contains("orca-repr-main-collapsed")) {
        this.state.highlightedBlocks.has(e) && e.style.removeProperty("background-color");
        return;
      }
      const s = e.querySelector(".orca-repr-children");
      if (s && Array.from(s.childNodes).some(
        (m) => {
          var I;
          return m.nodeType === 1 || // 元素节点
          m.nodeType === 3 && ((I = m.textContent) == null ? void 0 : I.trim()) !== "";
        }
        // 非空白文本节点
      )) {
        this.state.highlightedBlocks.has(e) && e.style.removeProperty("background-color");
        return;
      }
      const i = e.querySelector(".orca-repr-main-content.orca-repr-text-content");
      if (!i) {
        this.state.highlightedBlocks.has(e) && e.style.removeProperty("background-color");
        return;
      }
      const d = i.children;
      if (d.length !== 3) {
        this.state.highlightedBlocks.has(e) && e.style.removeProperty("background-color");
        return;
      }
      d[0].classList.contains("orca-none-selectable") && d[1].classList.contains("orca-inline") && d[1].dataset.type === "r" && d[2].classList.contains("orca-none-selectable") ? this.state.isHighlighted ? (e.style.backgroundColor = this.config.highlightColor, t.add(e)) : this.state.highlightedBlocks.has(e) && e.style.removeProperty("background-color") : this.state.highlightedBlocks.has(e) && e.style.removeProperty("background-color");
    }), this.state.highlightedBlocks = t;
  }
  /**
   * 切换高亮状态
   */
  toggleHighlightState() {
    this.state.isHighlighted = !this.state.isHighlighted, this.updateButtonStyle(), this.highlightMatchingBlocks(), this.saveState();
  }
  /**
   * 启用高亮
   */
  enableHighlight() {
    this.state.isHighlighted || (this.state.isHighlighted = !0, this.updateButtonStyle(), this.highlightMatchingBlocks(), this.saveState());
  }
  /**
   * 禁用高亮
   */
  disableHighlight() {
    this.state.isHighlighted && (this.state.isHighlighted = !1, this.updateButtonStyle(), this.highlightMatchingBlocks(), this.saveState());
  }
  /**
   * 保存状态到本地存储
   */
  saveState() {
    try {
      localStorage.setItem(this.config.storageKey, this.state.isHighlighted.toString());
    } catch (t) {
      console.error("状态保存失败:", t);
    }
  }
  /**
   * 创建背景色设置按钮
   */
  createButton() {
    const t = {
      id: this.config.buttonId,
      title: this.state.isHighlighted ? "取消仅块引用区块背景色" : "设置仅块引用区块背景色"
    }, e = {
      active: {
        backgroundColor: "var(--orca-color-primary-light, rgba(22, 93, 255, 0.15))",
        iconColor: "var(--orca-color-primary, #165DFF)",
        title: "取消仅块引用区块背景色"
      },
      inactive: {
        backgroundColor: "transparent",
        iconColor: "var(--orca-color-text-secondary, #666)",
        title: "设置仅块引用区块背景色"
      }
    }, o = this.state.isHighlighted ? `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="3" y="3" width="18" height="18" rx="2" fill="currentColor" opacity="0.8"/>
      </svg>
    ` : `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="3" y="3" width="18" height="18" rx="2" stroke="currentColor" stroke-width="2"/>
      </svg>
    `;
    this.buttonEl = nt(
      t,
      e,
      this.state.isHighlighted,
      o,
      () => this.toggleHighlightState()
    ), this.buttonManager ? this.buttonManager.registerButton(
      this.config.buttonId,
      this.buttonEl,
      5,
      // 优先级：仅块引用背景色高亮按钮
      "queryBlockHighlightToggle",
      () => {
        this.updateButtonStyle();
      }
    ) : ct(
      () => {
        const r = lt(
          this.buttonEl,
          this.config.toolbarSelector,
          this.config.targetPanelSelector
        );
        return r && (this.state.retryCount = 0, this.state.isHighlighted && this.highlightMatchingBlocks(), this.updateButtonStyle()), r;
      },
      this.config.retryInterval,
      this.config.maxRetries,
      () => console.warn('无法添加"仅块引用背景色"按钮：超过最大重试次数')
    );
  }
  /**
   * 更新按钮图标
   */
  updateButtonIcon() {
    if (!this.buttonEl) return;
    const t = this.state.isHighlighted ? `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="3" y="3" width="18" height="18" rx="2" fill="#666" opacity="0.8"/>
      </svg>
    ` : `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect x="3" y="3" width="18" height="18" rx="2" stroke="#666" stroke-width="2"/>
      </svg>
    `;
    this.buttonEl.innerHTML = t;
  }
  /**
   * 更新按钮样式：根据状态切换颜色和背景
   */
  updateButtonStyle() {
    if (!this.buttonEl) return;
    this.updateButtonIcon();
    const t = {
      active: {
        backgroundColor: "var(--orca-color-primary-light, rgba(22, 93, 255, 0.15))",
        iconColor: "var(--orca-color-primary, #165DFF)",
        title: "取消仅块引用区块背景色"
      },
      inactive: {
        backgroundColor: "transparent",
        iconColor: "var(--orca-color-text-secondary, #666)",
        title: "设置仅块引用区块背景色"
      }
    };
    at(this.buttonEl, t, this.state.isHighlighted);
  }
  /**
   * 设置区块观察者：监听折叠状态和子内容变化，实时更新背景色
   */
  setupBlockObserver(t) {
    k(this.state.blockObserver), this.state.blockObserver = ut(
      t,
      () => {
        this.state.isHighlighted && this.highlightMatchingBlocks();
      }
    );
  }
  /**
   * 设置主观察者：监听面板切换，确保按钮在新页面正常工作
   */
  setupMainObserver() {
    this.state.mainObserver = ht(
      {
        targetPanelSelector: this.config.targetPanelSelector,
        toolbarSelector: this.config.toolbarSelector
      },
      (t) => {
        if (t) {
          const e = t.querySelector(this.config.toolbarSelector);
          e && (!this.buttonEl || !e.contains(this.buttonEl)) && this.createButton(), this.setupBlockObserver(t), this.state.isHighlighted && this.highlightMatchingBlocks();
        } else this.buttonEl && (this.buttonEl.remove(), this.buttonEl = null, k(this.state.blockObserver));
      }
    ), gt(this.state.mainObserver);
  }
}
class pt {
  constructor(t) {
    a(this, "state", {
      isHidden: !1,
      retryCount: 0,
      observer: null,
      isInitialized: !1
    });
    a(this, "config", U);
    a(this, "buttonEl", null);
    a(this, "buttonManager", null);
    this.buttonManager = t || null;
  }
  initialize() {
    this.state.isInitialized || (this.initState(), this.createButton(), this.state.isHidden && this.applyHideStyle(), this.setupObserver(), this.state.isInitialized = !0, console.log("✅ W95 镜像容器切换模块已初始化"));
  }
  destroy() {
    this.state.isInitialized && (this.buttonEl && (this.buttonEl.remove(), this.buttonEl = null), this.state.observer && (this.state.observer.disconnect(), this.state.observer = null), this.removeHideStyle(), this.state.isInitialized = !1, console.log("✅ W95 镜像容器切换模块已销毁"));
  }
  getAPI() {
    return {
      toggle: () => this.toggleState(),
      show: () => this.showContainers(),
      hide: () => this.hideContainers(),
      getState: () => this.state.isHidden,
      destroy: () => this.destroy()
    };
  }
  /**
   * 初始化状态
   */
  initState() {
    try {
      const t = localStorage.getItem(this.config.storageKey);
      this.state.isHidden = t === "true";
    } catch (t) {
      console.error("状态初始化失败:", t), this.state.isHidden = !1;
    }
  }
  /**
   * 切换状态
   */
  toggleState() {
    this.state.isHidden = !this.state.isHidden, this.updateButtonStyle(), this.state.isHidden ? this.applyHideStyle() : this.removeHideStyle(), this.saveState();
  }
  /**
   * 显示镜像容器
   */
  showContainers() {
    this.state.isHidden && (this.state.isHidden = !1, this.updateButtonStyle(), this.removeHideStyle(), this.saveState());
  }
  /**
   * 隐藏镜像容器
   */
  hideContainers() {
    this.state.isHidden || (this.state.isHidden = !0, this.updateButtonStyle(), this.applyHideStyle(), this.saveState());
  }
  /**
   * 保存状态到本地存储
   */
  saveState() {
    try {
      localStorage.setItem(this.config.storageKey, this.state.isHidden.toString());
    } catch (t) {
      console.error("状态保存失败:", t);
    }
  }
  /**
   * 应用隐藏样式
   */
  applyHideStyle() {
    let t = document.getElementById(this.config.styleId);
    t || (t = document.createElement("style"), t.id = this.config.styleId, document.head.appendChild(t)), t.textContent = `
      .orca-query-list-block:has(> .orca-block.orca-container[data-type="mirror"]) {
        display: none !important;
      }
    `;
  }
  /**
   * 移除隐藏样式
   */
  removeHideStyle() {
    const t = document.getElementById(this.config.styleId);
    t && t.remove();
  }
  /**
   * 创建按钮
   */
  createButton() {
    const t = document.getElementById(this.config.buttonId);
    t && t.remove();
    const e = document.createElement("button");
    if (e.id = this.config.buttonId, e.title = this.state.isHidden ? "显示镜像容器" : "隐藏镜像容器", e.style.width = "24px", e.style.height = "24px", e.style.margin = "5px 8px", e.style.padding = "0", e.style.border = "none", e.style.borderRadius = "3px", e.style.backgroundColor = "transparent", e.style.cursor = "pointer", e.style.display = "flex", e.style.alignItems = "center", e.style.justifyContent = "center", e.style.transition = "all 0.2s ease", e.addEventListener("click", () => this.toggleState()), this.buttonManager)
      this.buttonManager.registerButton(
        this.config.buttonId,
        e,
        6,
        // 优先级：镜像容器切换按钮
        "mirrorContainerToggle",
        () => {
          this.updateButtonStyle();
        }
      );
    else {
      const o = document.querySelector(this.config.targetPanelSelector);
      if (o) {
        const r = o.querySelector(this.config.toolbarSelector);
        if (r) {
          r.appendChild(e), this.buttonEl = e, this.state.retryCount = 0, this.state.isHidden && this.applyHideStyle(), this.updateButtonStyle();
          return;
        }
      }
      this.state.retryCount < this.config.maxRetries ? (this.state.retryCount++, setTimeout(() => this.createButton(), this.config.retryInterval)) : console.warn("无法添加镜像容器切换按钮：超过最大重试次数");
    }
  }
  /**
   * 更新按钮图标
   */
  updateButtonIcon() {
    const t = document.getElementById(this.config.buttonId);
    t && (this.state.isHidden ? t.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5ZM12 17C9.24 17 7 14.76 7 12C7 9.24 9.24 7 12 7C14.76 7 17 9.24 17 12C17 14.76 14.76 17 12 17ZM16.24 7.76C14.97 6.49 13.51 5.03 12.24 3.76L10.76 5.24C12.03 6.51 13.49 7.97 14.76 9.24L16.24 7.76Z" fill="#666"/>
        </svg>
      ` : t.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 4.5C7 4.5 2.73 7.61 1 12C2.73 16.39 7 19.5 12 19.5C17 19.5 21.27 16.39 23 12C21.27 7.61 17 4.5 12 4.5ZM12 17C9.24 17 7 14.76 7 12C7 9.24 9.24 7 12 7C14.76 7 17 9.24 17 12C17 14.76 14.76 17 12 17ZM16.24 7.76L14.76 9.24C13.49 7.97 12.03 6.51 10.76 5.24L12.24 3.76C13.51 5.03 14.97 6.49 16.24 7.76Z" fill="#666"/>
        </svg>
      `);
  }
  /**
   * 更新按钮样式
   */
  updateButtonStyle() {
    const t = document.getElementById(this.config.buttonId);
    if (!t) return;
    this.updateButtonIcon();
    const e = t.querySelectorAll("svg path");
    this.state.isHidden ? (t.style.backgroundColor = "var(--orca-color-primary-light, rgba(22, 93, 255, 0.15))", e.forEach((o) => o.setAttribute("fill", "var(--orca-color-primary, #165DFF)")), t.title = "显示镜像容器") : (t.style.backgroundColor = "transparent", e.forEach((o) => o.setAttribute("fill", "var(--orca-color-text-secondary, #666)")), t.title = "隐藏镜像容器");
  }
  /**
   * 设置观察者
   */
  setupObserver() {
    this.state.observer = new MutationObserver((t) => {
      const e = document.getElementById(this.config.buttonId), o = document.querySelector(this.config.targetPanelSelector);
      if (o) {
        const r = o.querySelector(this.config.toolbarSelector);
        r && (!e || !r.contains(e)) && this.createButton();
      } else e && e.remove();
    }), this.state.observer.observe(document.body, {
      childList: !0,
      subtree: !0,
      attributes: !0,
      attributeFilter: ["class"]
    });
  }
}
class bt {
  constructor(t) {
    a(this, "state", {
      isHidden: !1,
      retryCount: 0,
      observer: null,
      isInitialized: !1
    });
    a(this, "config", Z);
    a(this, "buttonEl", null);
    a(this, "buttonManager", null);
    this.buttonManager = t || null;
  }
  initialize() {
    this.state.isInitialized || (this.initState(), this.createButton(), this.state.isHidden && this.applyHideStyle(), this.setupObserver(), this.state.isInitialized = !0, console.log("✅ W95 列表面包屑切换模块已初始化"));
  }
  destroy() {
    this.state.isInitialized && (this.buttonEl && (this.buttonEl.remove(), this.buttonEl = null), this.state.observer && (this.state.observer.disconnect(), this.state.observer = null), this.removeHideStyle(), this.state.isInitialized = !1, console.log("✅ W95 列表面包屑切换模块已销毁"));
  }
  getAPI() {
    return {
      toggle: () => this.toggleState(),
      show: () => this.showBreadcrumbs(),
      hide: () => this.hideBreadcrumbs(),
      getState: () => this.state.isHidden,
      destroy: () => this.destroy()
    };
  }
  /**
   * 初始化状态
   */
  initState() {
    try {
      const t = localStorage.getItem(this.config.storageKey);
      this.state.isHidden = t === "true";
    } catch (t) {
      console.error("状态初始化失败:", t), this.state.isHidden = !1;
    }
  }
  /**
   * 切换状态
   */
  toggleState() {
    this.state.isHidden = !this.state.isHidden, this.updateButtonStyle(), this.state.isHidden ? this.applyHideStyle() : this.removeHideStyle(), this.saveState();
  }
  /**
   * 显示面包屑
   */
  showBreadcrumbs() {
    this.state.isHidden && (this.state.isHidden = !1, this.updateButtonStyle(), this.removeHideStyle(), this.saveState());
  }
  /**
   * 隐藏面包屑
   */
  hideBreadcrumbs() {
    this.state.isHidden || (this.state.isHidden = !0, this.updateButtonStyle(), this.applyHideStyle(), this.saveState());
  }
  /**
   * 保存状态到本地存储
   */
  saveState() {
    try {
      localStorage.setItem(this.config.storageKey, this.state.isHidden.toString());
    } catch (t) {
      console.error("状态保存失败:", t);
    }
  }
  /**
   * 应用隐藏样式
   */
  applyHideStyle() {
    let t = document.getElementById(this.config.styleId);
    t || (t = document.createElement("style"), t.id = this.config.styleId, document.head.appendChild(t)), t.textContent = `
      .orca-breadcrumb.orca-block-breadcrumb.orca-query-list-block-breadcrumb {
        display: none !important;
      }
    `;
  }
  /**
   * 移除隐藏样式
   */
  removeHideStyle() {
    const t = document.getElementById(this.config.styleId);
    t && t.remove();
  }
  /**
   * 创建按钮
   */
  createButton() {
    const t = document.getElementById(this.config.buttonId);
    t && t.remove();
    const e = document.createElement("button");
    if (e.id = this.config.buttonId, e.title = this.state.isHidden ? "显示列表面包屑" : "隐藏列表面包屑", e.style.width = "24px", e.style.height = "24px", e.style.margin = "5px 8px", e.style.padding = "0", e.style.border = "none", e.style.borderRadius = "3px", e.style.backgroundColor = "transparent", e.style.cursor = "pointer", e.style.display = "flex", e.style.alignItems = "center", e.style.justifyContent = "center", e.style.transition = "all 0.2s ease", e.addEventListener("click", () => this.toggleState()), this.buttonManager)
      this.buttonManager.registerButton(
        this.config.buttonId,
        e,
        7,
        // 优先级：列表面包屑切换按钮
        "listBreadcrumbToggle",
        () => {
          this.updateButtonStyle();
        }
      );
    else {
      const o = document.querySelector(this.config.targetPanelSelector);
      if (o) {
        const r = o.querySelector(this.config.toolbarSelector);
        if (r) {
          r.appendChild(e), this.buttonEl = e, this.state.retryCount = 0, this.state.isHidden && this.applyHideStyle(), this.updateButtonStyle();
          return;
        }
      }
      this.state.retryCount < this.config.maxRetries ? (this.state.retryCount++, setTimeout(() => this.createButton(), this.config.retryInterval)) : console.warn("无法添加列表面包屑切换按钮：超过最大重试次数");
    }
  }
  /**
   * 更新按钮图标
   */
  updateButtonIcon() {
    const t = document.getElementById(this.config.buttonId);
    t && (this.state.isHidden ? t.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M10 6L8.59 7.41 13.17 12L8.59 16.59 10 18L16 12L10 6Z" fill="#666"/>
          <path d="M3 12L5 10V14L3 12Z" fill="#666"/>
          <path d="M20 10L22 12L20 14V10Z" fill="#666"/>
        </svg>
      ` : t.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M10 6L8.59 7.41 13.17 12L8.59 16.59 10 18L16 12L10 6Z" fill="#666"/>
          <path d="M3 12L5 10V14L3 12Z" fill="#666"/>
        </svg>
      `);
  }
  /**
   * 更新按钮样式
   */
  updateButtonStyle() {
    const t = document.getElementById(this.config.buttonId);
    if (!t) return;
    this.updateButtonIcon();
    const e = t.querySelectorAll("svg path"), o = t.querySelectorAll("svg stroke");
    this.state.isHidden ? (t.style.backgroundColor = "var(--orca-color-primary-light, rgba(22, 93, 255, 0.15))", e.forEach((r) => r.setAttribute("fill", "var(--orca-color-primary, #165DFF)")), t.title = "显示列表面包屑") : (t.style.backgroundColor = "transparent", e.forEach((r) => r.setAttribute("fill", "var(--orca-color-text-secondary, #666)")), o.length > 0 && o.forEach((r) => r.setAttribute("stroke", "var(--orca-color-text-secondary, #666)")), t.title = "隐藏列表面包屑");
  }
  /**
   * 设置观察者
   */
  setupObserver() {
    this.state.observer = new MutationObserver((t) => {
      const e = document.getElementById(this.config.buttonId), o = document.querySelector(this.config.targetPanelSelector);
      if (o) {
        const r = o.querySelector(this.config.toolbarSelector);
        r && (!e || !r.contains(e)) && this.createButton();
      } else e && e.remove();
    }), this.state.observer.observe(document.body, {
      childList: !0,
      subtree: !0,
      attributes: !0,
      attributeFilter: ["class"]
    });
  }
}
class yt {
  constructor(t) {
    a(this, "state", {
      isMinimal: !1,
      retryCount: 0,
      observer: null,
      isInitialized: !1
    });
    a(this, "config", Y);
    a(this, "buttonEl", null);
    a(this, "buttonManager", null);
    this.buttonManager = t || null;
  }
  initialize() {
    this.state.isInitialized || (this.initState(), this.createButton(), this.state.isMinimal && this.applyMinimalStyle(), this.setupObserver(), this.state.isInitialized = !0, console.log("✅ W95 卡片视图极简切换模块已初始化"));
  }
  destroy() {
    this.state.isInitialized && (this.buttonEl && (this.buttonEl.remove(), this.buttonEl = null), this.state.observer && (this.state.observer.disconnect(), this.state.observer = null), this.removeMinimalStyle(), this.state.isInitialized = !1, console.log("✅ W95 卡片视图极简切换模块已销毁"));
  }
  getAPI() {
    return {
      toggle: () => this.toggleState(),
      enable: () => this.enableMinimal(),
      disable: () => this.disableMinimal(),
      getState: () => this.state.isMinimal,
      destroy: () => this.destroy()
    };
  }
  /**
   * 初始化状态
   */
  initState() {
    try {
      const t = localStorage.getItem(this.config.storageKey);
      this.state.isMinimal = t === "true";
    } catch (t) {
      console.error("状态初始化失败:", t), this.state.isMinimal = !1;
    }
  }
  /**
   * 切换状态
   */
  toggleState() {
    this.state.isMinimal = !this.state.isMinimal, this.updateButtonStyle(), this.state.isMinimal ? this.applyMinimalStyle() : this.removeMinimalStyle(), this.saveState();
  }
  /**
   * 启用极简视图
   */
  enableMinimal() {
    this.state.isMinimal || (this.state.isMinimal = !0, this.updateButtonStyle(), this.applyMinimalStyle(), this.saveState());
  }
  /**
   * 禁用极简视图
   */
  disableMinimal() {
    this.state.isMinimal && (this.state.isMinimal = !1, this.updateButtonStyle(), this.removeMinimalStyle(), this.saveState());
  }
  /**
   * 保存状态到本地存储
   */
  saveState() {
    try {
      localStorage.setItem(this.config.storageKey, this.state.isMinimal.toString());
    } catch (t) {
      console.error("状态保存失败:", t);
    }
  }
  /**
   * 应用极简样式
   */
  applyMinimalStyle() {
    let t = document.getElementById(this.config.styleId);
    t || (t = document.createElement("style"), t.id = this.config.styleId, document.head.appendChild(t)), t.textContent = `
      .orca-breadcrumb.orca-block-breadcrumb.orca-query-card-breadcrumb {
        display: none !important;
      }
      .orca-query-card-title.orca-query-card-title-foldable {
        display: none !important;
      }
      .orca-query-card-title {
        display: none !important;
      }
    `;
  }
  /**
   * 移除极简样式
   */
  removeMinimalStyle() {
    const t = document.getElementById(this.config.styleId);
    t && t.remove();
  }
  /**
   * 创建按钮
   */
  createButton() {
    const t = document.getElementById(this.config.buttonId);
    t && t.remove();
    const e = document.createElement("button");
    if (e.id = this.config.buttonId, e.title = this.state.isMinimal ? "恢复完整视图" : "切换到极简视图", e.style.width = "24px", e.style.height = "24px", e.style.margin = "5px 8px", e.style.padding = "0", e.style.border = "none", e.style.borderRadius = "3px", e.style.backgroundColor = "transparent", e.style.cursor = "pointer", e.style.display = "flex", e.style.alignItems = "center", e.style.justifyContent = "center", e.style.transition = "all 0.2s ease", e.addEventListener("click", () => this.toggleState()), this.buttonManager)
      this.buttonManager.registerButton(
        this.config.buttonId,
        e,
        8,
        // 优先级：卡片视图极简切换按钮
        "cardViewMinimalToggle",
        () => {
          this.updateButtonStyle();
        }
      );
    else {
      const o = document.querySelector(this.config.targetPanelSelector);
      if (o) {
        const r = o.querySelector(this.config.toolbarSelector);
        if (r) {
          r.appendChild(e), this.buttonEl = e, this.state.retryCount = 0, this.state.isMinimal && this.applyMinimalStyle(), this.updateButtonStyle();
          return;
        }
      }
      this.state.retryCount < this.config.maxRetries ? (this.state.retryCount++, setTimeout(() => this.createButton(), this.config.retryInterval)) : console.warn("无法添加卡片视图极简切换按钮：超过最大重试次数");
    }
  }
  /**
   * 更新按钮图标
   */
  updateButtonIcon() {
    const t = document.getElementById(this.config.buttonId);
    t && (this.state.isMinimal ? t.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M3 5v14c0 1.1 0.9 2 2 2h14c1.1 0 2-0.9 2-2V5c0-1.1-0.9-2-2-2H5c-1.1 0-2 0.9-2 2zm16 14H5V5h14v14zM7 7h5v5H7V7zm0 7h5v2H7v-2zm7-7h2v5h-2V7zm0 7h2v2h-2v-2z" fill="#666"/>
        </svg>
      ` : t.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M3 5v14c0 1.1 0.9 2 2 2h14c1.1 0 2-0.9 2-2V5c0-1.1-0.9-2-2-2H5c-1.1 0-2 0.9-2 2zm16 14H5V5h14v14zM7 7h10v2H7V7zm0 4h10v2H7v-2zm0 4h7v2H7v-2z" fill="#666"/>
        </svg>
      `);
  }
  /**
   * 更新按钮样式
   */
  updateButtonStyle() {
    const t = document.getElementById(this.config.buttonId);
    if (!t) return;
    this.updateButtonIcon();
    const e = t.querySelectorAll("svg path");
    this.state.isMinimal ? (t.style.backgroundColor = "var(--orca-color-primary-light, rgba(22, 93, 255, 0.15))", e.forEach((o) => o.setAttribute("fill", "var(--orca-color-primary, #165DFF)")), t.title = "恢复完整视图") : (t.style.backgroundColor = "transparent", e.forEach((o) => o.setAttribute("fill", "var(--orca-color-text-secondary, #666)")), t.title = "切换到极简视图");
  }
  /**
   * 设置观察者
   */
  setupObserver() {
    this.state.observer = new MutationObserver((t) => {
      const e = document.getElementById(this.config.buttonId), o = document.querySelector(this.config.targetPanelSelector);
      if (o) {
        const r = o.querySelector(this.config.toolbarSelector);
        r && (!e || !r.contains(e)) && this.createButton();
      } else e && e.remove();
    }), this.state.observer.observe(document.body, {
      childList: !0,
      subtree: !0,
      attributes: !0,
      attributeFilter: ["class"]
    });
  }
}
class ft {
  constructor(t) {
    a(this, "state", {
      currentState: 0,
      retryCount: 0,
      observer: null,
      isInitialized: !1
    });
    a(this, "config", Q);
    a(this, "buttonEl", null);
    a(this, "buttonManager", null);
    this.buttonManager = t || null;
  }
  initialize() {
    this.state.isInitialized || (this.initState(), this.createButton(), this.applyAspectRatioStyle(), this.setupObserver(), this.state.isInitialized = !0, console.log("✅ W95 卡片封面比例切换模块已初始化"));
  }
  destroy() {
    this.state.isInitialized && (this.buttonEl && (this.buttonEl.remove(), this.buttonEl = null), this.state.observer && (this.state.observer.disconnect(), this.state.observer = null), this.removeAspectRatioStyle(), this.state.isInitialized = !1, console.log("✅ W95 卡片封面比例切换模块已销毁"));
  }
  getAPI() {
    return {
      toggle: () => this.toggleState(),
      setState: (t) => this.setState(t),
      getState: () => this.state.currentState,
      getCurrentRatio: () => this.getCurrentRatio(),
      destroy: () => this.destroy()
    };
  }
  /**
   * 初始化状态
   */
  initState() {
    try {
      const t = localStorage.getItem(this.config.storageKey);
      this.state.currentState = t ? parseInt(t, 10) : 0, (this.state.currentState < 0 || this.state.currentState >= this.config.states.length) && (this.state.currentState = 0);
    } catch (t) {
      console.error("状态初始化失败:", t), this.state.currentState = 0;
    }
  }
  /**
   * 切换状态
   */
  toggleState() {
    this.state.currentState = (this.state.currentState + 1) % this.config.states.length, this.updateButtonStyle(), this.applyAspectRatioStyle(), this.saveState();
  }
  /**
   * 设置特定状态
   */
  setState(t) {
    t >= 0 && t < this.config.states.length && (this.state.currentState = t, this.updateButtonStyle(), this.applyAspectRatioStyle(), this.saveState());
  }
  /**
   * 获取当前比例
   */
  getCurrentRatio() {
    return this.config.states[this.state.currentState].ratio;
  }
  /**
   * 保存状态到本地存储
   */
  saveState() {
    try {
      localStorage.setItem(this.config.storageKey, this.state.currentState.toString());
    } catch (t) {
      console.error("状态保存失败:", t);
    }
  }
  /**
   * 应用比例样式
   */
  applyAspectRatioStyle() {
    let t = document.getElementById(this.config.styleId);
    t || (t = document.createElement("style"), t.id = this.config.styleId, document.head.appendChild(t));
    const e = this.state.currentState < 2 ? this.config.states[this.state.currentState].ratio : "auto";
    t.textContent = `
      .orca-query-card-cover {
        aspect-ratio: ${e} !important;
      }
    `;
  }
  /**
   * 移除比例样式
   */
  removeAspectRatioStyle() {
    const t = document.getElementById(this.config.styleId);
    t && t.remove();
  }
  /**
   * 创建按钮
   */
  createButton() {
    const t = document.getElementById(this.config.buttonId);
    t && t.remove();
    const e = document.createElement("button");
    if (e.id = this.config.buttonId, e.title = this.config.states[this.state.currentState].title, e.style.width = "24px", e.style.height = "24px", e.style.margin = "5px 8px", e.style.padding = "0", e.style.border = "none", e.style.borderRadius = "3px", e.style.backgroundColor = "transparent", e.style.cursor = "pointer", e.style.display = "flex", e.style.alignItems = "center", e.style.justifyContent = "center", e.style.transition = "all 0.2s ease", e.addEventListener("click", () => this.toggleState()), this.buttonManager)
      this.buttonManager.registerButton(
        this.config.buttonId,
        e,
        9,
        // 优先级：卡片封面比例切换按钮
        "cardCoverAspectRatioToggle",
        () => {
          this.updateButtonStyle();
        }
      );
    else {
      const o = document.querySelector(this.config.targetPanelSelector);
      if (o) {
        const r = o.querySelector(this.config.toolbarSelector);
        if (r) {
          r.appendChild(e), this.buttonEl = e, this.state.retryCount = 0, this.applyAspectRatioStyle(), this.updateButtonStyle();
          return;
        }
      }
      this.state.retryCount < this.config.maxRetries ? (this.state.retryCount++, setTimeout(() => this.createButton(), this.config.retryInterval)) : console.warn("无法添加卡片封面比例切换按钮：超过最大重试次数");
    }
  }
  /**
   * 更新按钮图标
   */
  updateButtonIcon(t) {
    switch (this.config.states[this.state.currentState].icon) {
      case "portrait":
        t.innerHTML = `
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 3H20V21H4V3ZM19 19H5V5H19V19Z" fill="#666"/>
            <path d="M8 7H16V11H8V7Z" fill="#666"/>
          </svg>
        `;
        break;
      case "landscape":
        t.innerHTML = `
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 3H20V21H4V3ZM19 19H5V5H19V19Z" fill="#666"/>
            <path d="M7 8H17V10H7V8Z" fill="#666"/>
          </svg>
        `;
        break;
      case "disabled":
        t.innerHTML = `
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 3H20V21H4V3ZM19 19H5V5H19V19Z" fill="#999"/>
            <path d="M15 8L9 16" stroke="#999" stroke-width="2" stroke-linecap="round"/>
          </svg>
        `;
        break;
    }
  }
  /**
   * 更新按钮样式
   */
  updateButtonStyle() {
    const t = document.getElementById(this.config.buttonId);
    if (!t) return;
    const e = t.querySelectorAll("svg path"), o = this.config.states[this.state.currentState];
    t.title = o.title, o.icon === "disabled" ? (t.style.backgroundColor = "transparent", t.style.opacity = "0.6", e.forEach((r) => {
      r.setAttribute("fill", "#999");
    })) : (t.style.backgroundColor = "var(--orca-color-primary-light, rgba(22, 93, 255, 0.15))", t.style.opacity = "1", e.forEach((r) => {
      r.setAttribute("fill", "var(--orca-color-primary, #165DFF)");
    })), this.updateButtonIcon(t);
  }
  /**
   * 设置观察者
   */
  setupObserver() {
    this.state.observer = new MutationObserver((t) => {
      const e = document.getElementById(this.config.buttonId), o = document.querySelector(this.config.targetPanelSelector);
      if (o) {
        const r = o.querySelector(this.config.toolbarSelector);
        r && (!e || !r.contains(e)) && this.createButton();
      } else e && e.remove();
    }), this.state.observer.observe(document.body, {
      childList: !0,
      subtree: !0,
      attributes: !0,
      attributeFilter: ["class"]
    });
  }
}
class St {
  constructor(t) {
    a(this, "state", {
      isEnabled: !0,
      retryCount: 0,
      observer: null,
      isInitialized: !1
    });
    a(this, "config", J);
    a(this, "buttonManager", null);
    this.buttonManager = t;
  }
  initialize() {
    this.state.isInitialized || (this.initState(), this.createButton(), this.applyStyle(), this.state.isEnabled && this.addCreationTimeToBlocks(), this.setupObserver(), this.state.isInitialized = !0, console.log("✅ W95 查询列表块创建时间显示模块已初始化"));
  }
  destroy() {
    this.state.isInitialized && (this.state.observer && (this.state.observer.disconnect(), this.state.observer = null), this.removeStyle(), this.removeAllCreationTimeDisplays(), this.state.isInitialized = !1, console.log("✅ W95 查询列表块创建时间显示模块已销毁"));
  }
  getAPI() {
    return {
      toggle: () => this.toggleState(),
      enable: () => this.enable(),
      disable: () => this.disable(),
      isEnabled: () => this.state.isEnabled,
      refresh: () => this.addCreationTimeToBlocks(),
      destroy: () => this.destroy(),
      getProcessedCount: () => document.querySelectorAll(".creation-time-wrapper").length,
      getTotalCount: () => document.querySelectorAll(this.config.targetSelector).length
    };
  }
  /**
   * 获取当前颜色方案
   */
  getCurrentColorScheme() {
    const t = document.documentElement.classList.contains("dark") || document.body.classList.contains("dark-mode") || getComputedStyle(document.body).backgroundColor === "rgb(43, 49, 61)", e = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;
    return t || e ? this.config.colorSchemes.dark : this.config.colorSchemes.light;
  }
  /**
   * 应用样式
   */
  applyStyle() {
    let t = document.getElementById(this.config.styleId);
    t || (t = document.createElement("style"), t.id = this.config.styleId, document.head.appendChild(t));
    const e = this.config.colorSchemes.light, o = this.config.colorSchemes.dark, r = e.map((i) => `
      .creation-time-container.period-${i.name} {
        background-color: ${i.bgColor || "transparent"} !important;
        color: ${i.textColor} !important;
        border-color: ${i.borderColor} !important;
      }
      .creation-time-container.period-${i.name} .time-icon {
        color: ${i.textColor} !important;
      }
    `).join(""), s = o.map((i) => `
      .creation-time-container.period-${i.name} {
        background-color: ${i.bgColor} !important;
        color: ${i.textColor} !important;
        border-color: ${i.borderColor} !important;
      }
      .creation-time-container.period-${i.name} .time-icon {
        color: ${i.textColor} !important;
      }
    `).join("");
    t.textContent = `
      /* 主容器样式 */
      .creation-time-wrapper {
        display: flex;
        justify-content: center;
        margin-top: 4px;
      }
      
      /* 时间显示容器样式 */
      .creation-time-container {
        align-self: flex-end;
        font-size: 11px;
        padding: 0;
        border-radius: 4px;
        border: none;
        opacity: 1;
        pointer-events: auto;
        z-index: 10;
        white-space: nowrap;
        font-family: var(--orca-font-family);
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        cursor: default;
        display: flex;
        align-items: center;
        gap: 4px;
        margin-right: 1px;
        font-weight: 800;
      }
      
      .time-icon {
        font-size: 12px;
        opacity: 1;
      }
      
      /* 亮色模式时段样式 */
      ${r}
      
      /* 暗色模式适配 */
      @media (prefers-color-scheme: dark), 
             :root.dark .creation-time-container, 
             body.dark-mode .creation-time-container,
             body[style*="background-color: rgb(43, 49, 61)"] .creation-time-container {
        ${s}
        
        .creation-time-container {
          box-shadow: 0 1px 3px rgba(0,0,0,0.3);
        }
      }
      
      /* 调整查询列表块的边距 */
      ${this.config.targetSelector} {
        margin-bottom: 4px;
      }
    `;
  }
  /**
   * 移除样式
   */
  removeStyle() {
    const t = document.getElementById(this.config.styleId);
    t && t.remove();
  }
  /**
   * 格式化时间
   */
  formatTime(t) {
    if (!t) return { formatted: "", period: null };
    const e = new Date(t), o = e.getHours(), r = this.getCurrentColorScheme();
    let s = null;
    for (const l of r)
      if (o >= l.start && o < l.end) {
        s = l;
        break;
      }
    const i = (l) => l.toString().padStart(2, "0");
    return { formatted: this.config.timeFormat.replace("YYYY", e.getFullYear().toString()).replace("MM", i(e.getMonth() + 1)).replace("DD", i(e.getDate())).replace("HH", i(e.getHours())).replace("mm", i(e.getMinutes())), period: s };
  }
  /**
   * 添加创建时间到块
   */
  addCreationTimeToBlocks() {
    if (!this.state.isEnabled) return;
    document.querySelectorAll(this.config.targetSelector).forEach((e) => {
      var m, I, C, f, B, b;
      if (e.nextElementSibling && e.nextElementSibling.classList.contains("creation-time-wrapper"))
        return;
      const o = e.getAttribute("data-id");
      if (!o) return;
      let r = (C = (I = (m = window.orca) == null ? void 0 : m.state) == null ? void 0 : I.blocks) == null ? void 0 : C[o];
      if (!r) {
        const y = (B = (f = window.orca) == null ? void 0 : f.state) == null ? void 0 : B.blocks;
        if (y) {
          for (const S in y)
            if (y[S].id == o) {
              r = y[S];
              break;
            }
        }
      }
      if (!r) return;
      const s = document.createElement("div");
      s.className = "creation-time-wrapper";
      const i = document.createElement("div");
      i.className = "creation-time-container";
      const { formatted: d, period: l } = this.formatTime(r.created);
      if (l) {
        const y = document.createElement("i");
        y.className = `time-icon ${l.icon}`, i.appendChild(y);
        const S = document.createElement("span");
        S.textContent = d, i.appendChild(S), i.classList.add(`period-${l.name}`), i.title = `${l.name}创建`;
      } else
        i.textContent = d;
      s.appendChild(i), (b = e.parentNode) == null || b.insertBefore(s, e.nextSibling);
    });
  }
  /**
   * 移除所有创建时间显示
   */
  removeAllCreationTimeDisplays() {
    document.querySelectorAll(".creation-time-wrapper").forEach((e) => e.remove());
  }
  /**
   * 设置观察者
   */
  setupObserver() {
    this.state.observer = new MutationObserver((t) => {
      let e = !1;
      t.forEach((o) => {
        o.type === "childList" && o.addedNodes.forEach((r) => {
          var s, i;
          r.nodeType === Node.ELEMENT_NODE && ((s = r.matches) != null && s.call(r, this.config.targetSelector) || (i = r.querySelector) != null && i.call(r, this.config.targetSelector)) && (e = !0);
        }), o.type === "attributes" && (o.target === document.documentElement || o.target === document.body) && (o.attributeName === "class" || o.attributeName === "style") && (this.applyStyle(), this.addCreationTimeToBlocks());
      }), e && this.addCreationTimeToBlocks();
    }), this.state.observer.observe(document.body, {
      childList: !0,
      subtree: !0,
      attributes: !0,
      attributeFilter: ["class", "style"]
    }), window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", () => {
      this.applyStyle(), this.addCreationTimeToBlocks();
    });
  }
  /**
   * 初始化状态
   */
  initState() {
    try {
      const t = localStorage.getItem(this.config.storageKey);
      this.state.isEnabled = t ? JSON.parse(t) : !0;
    } catch (t) {
      console.error("状态初始化失败:", t), this.state.isEnabled = !0;
    }
  }
  /**
   * 创建按钮
   */
  createButton() {
    if (!this.buttonManager) return;
    const t = document.createElement("button");
    t.id = this.config.buttonId, t.title = this.getButtonTitle(), t.style.width = "24px", t.style.height = "24px", t.style.margin = "5px 8px", t.style.padding = "0", t.style.border = "none", t.style.borderRadius = "3px", t.style.backgroundColor = "transparent", t.style.cursor = "pointer", t.style.display = "flex", t.style.alignItems = "center", t.style.justifyContent = "center", t.style.transition = "all 0.2s ease", t.style.outline = "none", t.style.boxSizing = "border-box", t.innerHTML = `<i class="${this.getButtonIcon()}" style="font-size: 14px;"></i>`, t.addEventListener("click", () => this.toggleState()), this.buttonManager.registerButton(
      this.config.buttonId,
      t,
      10,
      // 优先级
      "queryListBlockCreationTime",
      // 插件名称
      () => {
        this.updateButtonStyle();
      }
    );
  }
  /**
   * 获取按钮图标
   */
  getButtonIcon() {
    return this.state.isEnabled ? "ti ti-clock" : "ti ti-clock-off";
  }
  /**
   * 获取按钮标题
   */
  getButtonTitle() {
    return this.state.isEnabled ? "隐藏创建时间" : "显示创建时间";
  }
  /**
   * 切换状态
   */
  toggleState() {
    this.state.isEnabled = !this.state.isEnabled, this.saveState(), this.updateButtonStyle(), this.state.isEnabled ? this.addCreationTimeToBlocks() : this.removeCreationTimeFromBlocks();
  }
  /**
   * 启用功能
   */
  enable() {
    this.state.isEnabled || (this.state.isEnabled = !0, this.saveState(), this.updateButtonStyle(), this.addCreationTimeToBlocks());
  }
  /**
   * 禁用功能
   */
  disable() {
    this.state.isEnabled && (this.state.isEnabled = !1, this.saveState(), this.updateButtonStyle(), this.removeCreationTimeFromBlocks());
  }
  /**
   * 保存状态
   */
  saveState() {
    try {
      localStorage.setItem(this.config.storageKey, JSON.stringify(this.state.isEnabled));
    } catch (t) {
      console.error("状态保存失败:", t);
    }
  }
  /**
   * 更新按钮样式
   */
  updateButtonStyle() {
    const t = document.getElementById(this.config.buttonId);
    t && (t.innerHTML = `<i class="${this.getButtonIcon()}" style="font-size: 14px;"></i>`, t.title = this.getButtonTitle(), this.state.isEnabled ? (t.style.backgroundColor = "var(--orca-color-primary-1, rgba(24, 124, 201, 0.15))", t.style.color = "var(--orca-color-primary-5, #187cc9)") : (t.style.backgroundColor = "transparent", t.style.color = "var(--orca-color-text-2, #666)"));
  }
  /**
   * 移除所有创建时间显示
   */
  removeCreationTimeFromBlocks() {
    document.querySelectorAll(".creation-time-wrapper").forEach((t) => {
      t.remove();
    });
  }
}
let h = "";
const R = "css-injector-";
let u = !1, p = "", w = "";
function F() {
  const n = document.head || document.getElementsByTagName("head")[0], t = document.body || document.getElementsByTagName("body")[0];
  return { head: n, body: t };
}
function H() {
  if (!h) {
    console.warn("applyThemeStylesInternal called but currentPluginName is not set.");
    return;
  }
  try {
    const { head: n, body: t } = F();
    if (n) {
      const e = R + h;
      if (document.getElementById(e)) {
        console.log(`Plugin '${h}': Theme CSS link already exists (ID: ${e}).`), u = !0;
        return;
      }
      const o = document.createElement("link");
      o.rel = "stylesheet", o.type = "text/css", o.href = w, o.id = e, o.onload = () => {
        console.log(`Plugin '${h}': CSS loaded successfully.`), u = !0;
      }, o.onerror = () => {
        console.error(`Plugin '${h}': Failed to load CSS from ${w}.`), u = !1;
      }, n.appendChild(o), console.log(`Plugin '${h}': Custom CSS link created with ID '${o.id}'. Path: ${w}`);
    } else
      console.error(`Plugin '${h}': Could not find document head to inject CSS.`), u = !1;
  } catch (n) {
    console.error(`Plugin '${h}': Error applying theme styles.`, n), u = !1;
  }
}
function L() {
  if (!h) {
    console.warn("removeThemeStylesInternal called but currentPluginName is not set.");
    return;
  }
  try {
    const { body: n } = F(), t = R + h, e = document.getElementById(t);
    e ? (e.remove(), u = !1, console.log(`Plugin '${h}': Custom CSS unloaded by removing element with ID '${t}'.`)) : (u = !1, console.warn(`Plugin '${h}': No custom CSS link found to unload (expected ID: '${t}'). Current state set to inactive.`));
  } catch (n) {
    console.error(`Plugin '${h}': Error removing theme styles.`, n), u = !1;
  }
}
function M() {
  if (!h) {
    console.warn("toggleThemeCommandExecute called but currentPluginName is not set.");
    return;
  }
  console.log(`Command '${p}' executed. Current theme active state BEFORE toggle: ${u}`), u ? L() : H(), console.log(`Theme active state AFTER toggle: ${u}`);
}
class vt {
  constructor(t, e) {
    a(this, "state", {
      isThemeLoaded: !1,
      retryCount: 0,
      observer: null,
      isInitialized: !1
    });
    a(this, "config", X);
    a(this, "buttonEl", null);
    a(this, "buttonManager", null);
    a(this, "pluginName", "");
    a(this, "persistenceManager", null);
    this.buttonManager = t || null, this.pluginName = e || "", this.persistenceManager = this.pluginName ? $(this.pluginName) : null;
  }
  async initialize() {
    var e, o;
    if (this.state.isInitialized) return;
    h = this.pluginName, p = `${this.pluginName}.toggleTheme2`;
    const t = [
      "./css/theme2.css",
      "css/theme2.css",
      "./dist/css/theme2.css",
      "dist/css/theme2.css",
      "/css/theme2.css",
      "/dist/css/theme2.css"
    ];
    try {
      w = new URL("./css/theme2.css", import.meta.url).href, console.log(`[Theme2Toggle] CSS URL resolved to: ${w}`);
    } catch {
      w = t[0], console.log(`[Theme2Toggle] Using fallback CSS path: ${w}`);
    }
    console.log(`Plugin '${h}' LOADED. Attempting to apply theme by default. Command '${p}' will be registered.`);
    try {
      const r = (o = (e = window.orca) == null ? void 0 : e.commands) == null ? void 0 : o.registerCommand;
      r ? (r(p, M, "启用/关闭主题2"), console.log(`Plugin '${this.pluginName}': Command '${p}' successfully registered.`)) : console.warn(`Plugin '${this.pluginName}': orca.commands.registerCommand API not found. Command cannot be registered.`);
    } catch (r) {
      console.error(`Plugin '${this.pluginName}': Error registering command '${p}'.`, r);
    }
    this.createButton(), await this.initState(), this.state.isThemeLoaded && (console.log("[Theme2Toggle] 检测到已保存的主题2状态，正在恢复..."), H()), this.setupObserver(), this.state.isInitialized = !0, console.log(`Theme active state after initial load: ${u}`), console.log("✅ W95 主题2切换模块已初始化");
  }
  destroy() {
    var t, e;
    if (this.state.isInitialized) {
      console.log(`Plugin '${h}' UNLOADING...`);
      try {
        const o = (e = (t = window.orca) == null ? void 0 : t.commands) == null ? void 0 : e.unregisterCommand;
        o && p ? (o(p), console.log(`Plugin '${h}': Command '${p}' unregistered.`)) : console.warn(`Plugin '${h}': Command unregistration API not available or command ID unknown.`);
      } catch (o) {
        console.error(`Plugin '${h}': Error unregistering command.`, o);
      }
      L(), this.buttonEl && (this.buttonEl.remove(), this.buttonEl = null), this.state.observer && (this.state.observer.disconnect(), this.state.observer = null), console.log(`Plugin '${h}' UNLOADED. Theme state was: ${u}`), h = "", u = !1, p = "", w = "", this.state.isInitialized = !1, console.log("✅ W95 主题2切换模块已销毁");
    }
  }
  getAPI() {
    return {
      toggle: () => M(),
      loadTheme: () => H(),
      removeTheme: () => L(),
      getState: () => u,
      destroy: () => this.destroy()
    };
  }
  /**
   * 初始化状态
   */
  async initState() {
    console.log("[Theme2Toggle] 开始初始化状态...");
    try {
      if (this.persistenceManager)
        console.log("[Theme2Toggle] 使用Orca API加载状态"), this.state.isThemeLoaded = await this.persistenceManager.loadState("theme2Loaded", !1), console.log(`[Theme2Toggle] 从 Orca API 加载状态: ${this.state.isThemeLoaded}`);
      else {
        console.log("[Theme2Toggle] 降级到localStorage");
        const t = localStorage.getItem(this.config.storageKey);
        this.state.isThemeLoaded = t === "true", console.log(`[Theme2Toggle] 从 localStorage 加载状态: ${t} -> ${this.state.isThemeLoaded}`);
      }
    } catch (t) {
      console.error("[Theme2Toggle] 状态初始化失败:", t), this.state.isThemeLoaded = !1;
    }
  }
  /**
   * 获取内联主题2 CSS（备用方案）
   */
  getInlineTheme2CSS() {
    return `
:root{
@media (prefers-color-scheme: light) {
    --orca-color-menu-highlight: #2a7bb963 ;
    --orca-border-scope: 1px solid #dbd5cb !important;

    .orca-favorites-items {
        font-weight: 600;
    }

    .orca-query-list-block {
        border-radius: 0 !important;
        background: #f3f1ed ;
        border-radius: 10px !important;
        border-top: none !important;
        border-left: none !important; 
        border-right: none !important; 
        border-bottom: none !important;
        border: 1px solid #0000002b !important;
    }

    header#headbar {
        background: #e1e1e100 !important;
    }

    .orca-headbar-sidebar-tools {
        border-top: none !important;
        border-left: none !important; 
        border-right: none !important; 
        border-bottom: none !important;
    }

    button.orca-button.plain.orca-headbar-sidebar-toggle {
        border-top: none !important;
        border-left: none !important; 
        border-right: none !important; 
        border-bottom: none !important;
    }

    #sidebar {
        --orca-color-bg-1: #EEE9E2 !important;
        --orca-color-text-1: #222222 !important;
        color: #67635B !important;
    }

    button.orca-button.plain.orca-select-button.orca-repo-switcher-button {
        border-top: none !important;
        border-left: none !important; 
        border-right: none !important; 
        border-bottom: none !important;
        border-radius: 10px !important;
        background: #ffffff38 !important;
    }

    .days {
        border-right: 0 !important;
        box-shadow: inset 0 0 75px rgb(165 165 165 / 25%) !important;
        border-radius: 10px !important;
        padding: 9px !important;
        border:none !important;
    }

    .orca-sidebar-tabs {
        margin: 0 calc(-0 * var(--orca-spacing-md)) !important;
        background: none !important;
        border: none !important;
        border-right: none !important;
        box-shadow: none !important;
    }

    .orca-sidebar-tab-options {
        background-color: #F8F8F8 !important;
        border-radius: 10px !important; 
    }

    span.orca-input-input {
        border-top: none !important;
        border-left: none !important; 
        border-right: none !important; 
        border-bottom: none !important;
    }

    .orca-sidebar-create-aliased-btn.orca-button {
        background-color: #F7F7F7 !important;
        border-top: none !important;
        border-left: none !important; 
        border-right: none !important; 
        border-bottom: none !important;
        border-radius: 10px !important;
    }

    .orca-fav-item-item:hover .orca-fav-item-icon, .orca-tags-tag-item:hover .orca-tags-tag-icon, .orca-aliased-block-item:hover .orca-aliased-block-icon {
        background-color: hsl(0deg 0% 35% / 9%) !important;
        border-top: none !important;
        border-left: none !important; 
        border-right: none !important; 
        border-bottom: none !important;
        border-radius: 0px !important;
        animation: none !important;
    }

    .orca-block-editor {
        background-image: radial-gradient(circle, rgba(71, 71, 71, 0.11) 1px, transparent 1px) !important;
        background-size: 25px 25px !important;
        background: #f5f1ea2e !important;
        border: none !important;
        box-shadow: none !important;
        caret-color: #ff6b6b !important;
    }
    
    .orca-container ::selection {
        background-color: #995C5C ;
    }

    div#app {
        background-image: radial-gradient(circle, rgba(71, 71, 71, 0.11) 1px, transparent 1px) !important;
        background-size: 25px 25px !important;
        background-color: #e5dccb7a !important;
    }
    
    .orca-menu {
        border-radius: 0 !important;
        border-top: none !important;
        border-left: none !important; 
        border-right: none !important; 
        border-bottom: none !important;
        padding: 0 !important;
    }

    .orca-toc {
        border: none !important;
        background: #f7f7f7ab !important;
        background-image: radial-gradient(circle, rgba(71, 71, 71, 0.11) 1px, transparent 1px) !important;
        background-size: 25px 25px !important;
    }

    .orca-query-result-list-toolbar {
        border-radius: 10px !important;
        border-top: none !important;
        border-left: none !important; 
        border-right: none !important; 
        border-bottom: none !important;
        background: #f3f3f38c !important;
        padding-left: 6px !important;
        padding-right: 6px !important;
    }
    
    button.orca-button.soft.orca-query-conditions-reset {
        border-radius: 10px !important;
        border-top: none !important;
        border-left: none !important; 
        border-right: none !important; 
        border-bottom: none !important;
    }

    span.orca-tag-tag {
        font-weight: 600 !important;
        padding-left: 5px !important;
        padding-right: 5px !important;
        font-size: 10px !important;
        border-radius: 5px !important;
        background: #ffffff !important;
        border-top: none !important;
        border-left: none !important; 
        border-right: none !important; 
        border-bottom: none !important;
        border: var(--orca-border-general) !important;
    }

    .orca-menu {
        padding: var(--orca-spacing-sm) !important;
        border-radius: 10px !important;
    }

    .orca-menu-title {
        border-radius: 10px !important;
        border-top: none !important;
        border-left: none !important; 
        border-right: none !important; 
        border-bottom: none !important;
    }

    .orca-query-card {
        background-color: #F7F7F7 !important;
        border-top: none !important;
        border-left: none !important; 
        border-right: none !important; 
        border-bottom: none !important;
        border-radius: 10px !important;
    }

    .orca-segmented:not(.orca-transitioning) .orca-segmented-item.orca-selected {
        background-color: var(--orca-color-bg-1) !important;
        box-shadow: var(--orca-shadow-segmented) !important;
        border-top: none !important;
        border-left: none !important;
        border-right: none !important;
        border-bottom: none !important;
    }

    .orca-menu-item:hover {
        background-color: var(--orca-color-menu-highlight) !important;
    }

    .orca-repo-switcher-selected:hover {
        background-color: var(--orca-color-menu-highlight) !important;
    }

    .orca-menu-text {
        border-radius: 10px !important;
        border-top: none !important;
        border-left: none !important; 
        border-right: none !important; 
        border-bottom: none !important;
    }

    .orca-menu-text:not(.orca-menu-text-disabled):hover {
        background-color: var(--orca-color-menu-highlight) !important;
    }

    #sidebar .orca-button.plain:not(:disabled):active {
        background-color: #f8f8f8ad !important;
        opacity: 0.7 !important;
    }

    .orca-fav-item-icon, .orca-tags-tag-icon, .orca-aliased-block-icon{
        color: #AF8380 !important;
    }

    span.orca-input.orca-tags-list-filter, span.orca-input.orca-aliased-filter {
        border-top: none !important;
    }

    button.orca-button.plain.orca-block-editor-query-add-btn {
        border-radius: 20px !important;
        border-top: none !important;
        border-left: none !important; 
        border-right: none !important; 
        border-bottom: none !important;
        background: #ffffff !important;
    }

    .orca-repr.orca-mirror-bg:before {
        border-radius: 10px;
        border: 1px solid hsl(0deg 0% 0% / 23%);
        background-color: #F3F1ED;
    }

    .highlight {
        background-color: #ce1d1d98;
        color: #ffffff;
        font-weight: 700;
    }
    
    textarea.orca-textarea.orca-tag-data-textarea.orca-tag-data-text-break {
        border-radius: 8px;
    }
    
    span.orca-textarea-input{
        border-radius: 8px; 
    }
    
    .orca-segmented:not(.orca-transitioning) .orca-segmented-item.orca-selected{
        border-radius: 8px !important; 
    }
}
}`;
  }
  /**
   * 保存状态到Orca数据存储
   */
  async saveState() {
    console.log(`[Theme2Toggle] 保存状态: ${this.state.isThemeLoaded}`);
    try {
      this.persistenceManager ? (await this.persistenceManager.saveState("theme2Loaded", this.state.isThemeLoaded), console.log(`[Theme2Toggle] 状态已保存到Orca API: ${this.state.isThemeLoaded}`)) : (localStorage.setItem(this.config.storageKey, this.state.isThemeLoaded.toString()), console.log(`[Theme2Toggle] 状态已保存到localStorage: ${this.state.isThemeLoaded}`));
    } catch (t) {
      console.error("[Theme2Toggle] 状态保存失败:", t);
    }
  }
  /**
   * 创建按钮
   */
  createButton() {
    const t = document.getElementById(this.config.buttonId);
    t && t.remove();
    const e = document.createElement("button");
    if (e.id = this.config.buttonId, e.title = this.state.isThemeLoaded ? "切换到默认主题" : "切换到主题2", e.style.width = "24px", e.style.height = "24px", e.style.margin = "5px 8px", e.style.padding = "0", e.style.border = "none", e.style.borderRadius = "3px", e.style.backgroundColor = "transparent", e.style.cursor = "pointer", e.style.display = "flex", e.style.alignItems = "center", e.style.justifyContent = "center", e.style.transition = "all 0.2s ease", e.addEventListener("click", () => {
      M(), this.updateButtonStyle();
    }), this.buttonManager)
      this.buttonManager.registerButton(
        this.config.buttonId,
        e,
        3,
        // 优先级：主题2切换按钮（调整到标题编号之后）
        "theme2Toggle",
        () => {
          this.updateButtonStyle();
        }
      );
    else {
      const o = document.querySelector(".orca-panel.active");
      if (o) {
        const r = o.querySelector(this.config.toolbarSelector);
        if (r) {
          r.appendChild(e), this.buttonEl = e, this.state.retryCount = 0;
          return;
        }
      }
      this.state.retryCount < this.config.maxRetries ? (this.state.retryCount++, setTimeout(() => this.createButton(), this.config.retryInterval)) : console.warn("无法添加主题2切换按钮：超过最大重试次数");
    }
  }
  /**
   * 更新按钮图标
   */
  updateButtonIcon(t) {
    u ? t.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="2" fill="none"/>
          <circle cx="12" cy="12" r="6" stroke="currentColor" stroke-width="1" fill="none"/>
          <circle cx="12" cy="12" r="2" fill="currentColor"/>
        </svg>
      ` : t.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 19l7-7 3 3-7 7-3-3z" stroke="currentColor" stroke-width="2" fill="none"/>
          <path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z" stroke="currentColor" stroke-width="2" fill="none"/>
          <path d="M2 2l7.586 7.586" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
          <circle cx="11" cy="11" r="2" stroke="currentColor" stroke-width="2" fill="none"/>
        </svg>
      `;
  }
  /**
   * 更新按钮样式
   */
  updateButtonStyle() {
    const t = document.getElementById(this.config.buttonId);
    if (!t) return;
    const e = t.querySelectorAll("svg circle, svg line, svg path");
    u ? (t.style.backgroundColor = "var(--orca-color-primary-light, rgba(22, 93, 255, 0.15))", e.forEach((o) => o.setAttribute("stroke", "var(--orca-color-primary, #165DFF)")), t.title = "切换到默认主题") : (t.style.backgroundColor = "transparent", e.forEach((o) => o.setAttribute("stroke", "var(--orca-color-text-secondary, #666)")), t.title = "切换到主题2"), this.updateButtonIcon(t);
  }
  /**
   * 设置观察者
   */
  setupObserver() {
    this.state.observer = new MutationObserver((t) => {
      const e = document.getElementById(this.config.buttonId), o = document.querySelector(".orca-panel.active");
      if (o) {
        const r = o.querySelector(this.config.toolbarSelector);
        r && (!e || !r.contains(e)) && this.createButton();
      } else e && e.remove();
    }), this.state.observer.observe(document.body, {
      childList: !0,
      subtree: !0,
      attributes: !0,
      attributeFilter: ["class"]
    });
  }
}
class wt {
  constructor() {
    a(this, "state", {
      currentState: 0,
      retryCount: 0,
      mainObserver: null,
      originalDisplayMap: /* @__PURE__ */ new Map(),
      isInitialized: !1
    });
    a(this, "config", tt);
  }
  initialize() {
    this.state.isInitialized || (this.initState(), this.createButton(), this.setupMainObserver(), this.state.isInitialized = !0, console.log("✅ W95 隐藏OCR图片块模块已初始化"));
  }
  destroy() {
    if (!this.state.isInitialized) return;
    const t = document.getElementById(this.config.buttonId);
    t && t.remove(), this.state.mainObserver && (this.state.mainObserver.disconnect(), this.state.mainObserver = null), this.restoreAllBlocksDisplay(), this.state.isInitialized = !1, console.log("✅ W95 隐藏OCR图片块模块已销毁");
  }
  getAPI() {
    return {
      toggle: () => this.toggleTripleState(),
      setState: (t) => this.setState(t),
      getState: () => this.state.currentState,
      updateBlocksDisplay: () => this.updateBlocksDisplay(),
      destroy: () => this.destroy()
    };
  }
  /**
   * 初始化状态
   */
  initState() {
    try {
      const t = localStorage.getItem(this.config.storageKey);
      this.state.currentState = t ? parseInt(t, 10) : 0, (this.state.currentState < 0 || this.state.currentState > 2) && (this.state.currentState = 0);
    } catch (t) {
      console.error("状态初始化失败:", t), this.state.currentState = 0;
    }
  }
  /**
   * 检查是否为OCR图片块
   */
  isOcrImageBlock(t) {
    const e = t.querySelector(this.config.photoClassSelector);
    return e ? window.getComputedStyle(e, ":before").content === '"\\e84a"' : !1;
  }
  /**
   * 更新块的显示状态
   */
  updateBlocksDisplay() {
    document.querySelectorAll(this.config.targetBlockSelector).forEach((t) => {
      if (!this.state.originalDisplayMap.has(t)) {
        const e = t.style.display || window.getComputedStyle(t).display;
        this.state.originalDisplayMap.set(t, e);
      }
    }), document.querySelectorAll(this.config.targetBlockSelector).forEach((t) => {
      const e = this.isOcrImageBlock(t);
      switch (this.state.currentState) {
        case 1:
          t.style.display = e ? "none" : this.state.originalDisplayMap.get(t) || "";
          break;
        case 2:
          t.style.display = e ? this.state.originalDisplayMap.get(t) || "" : "none";
          break;
        case 0:
          t.style.display = this.state.originalDisplayMap.get(t) || "";
          break;
      }
    });
  }
  /**
   * 恢复所有块的原始显示状态
   */
  restoreAllBlocksDisplay() {
    this.state.originalDisplayMap.forEach((t, e) => {
      e.style.display = t;
    });
  }
  /**
   * 切换三重状态
   */
  toggleTripleState() {
    this.state.currentState = (this.state.currentState + 1) % 3, this.updateButtonStyle(), this.updateBlocksDisplay(), this.saveState();
  }
  /**
   * 设置特定状态
   */
  setState(t) {
    t >= 0 && t <= 2 && (this.state.currentState = t, this.updateButtonStyle(), this.updateBlocksDisplay(), this.saveState());
  }
  /**
   * 保存状态到本地存储
   */
  saveState() {
    try {
      localStorage.setItem(this.config.storageKey, this.state.currentState.toString());
    } catch (t) {
      console.error("状态保存失败:", t);
    }
  }
  /**
   * 创建按钮
   */
  createButton() {
    const t = document.getElementById(this.config.buttonId);
    t && t.remove();
    let e = document.querySelector(this.config.containerSelector), o = null;
    if (e)
      o = e.querySelector(this.config.footerSelector);
    else {
      const s = [
        ".orca-menu",
        ".search-modal",
        ".modal",
        '[class*="search"]',
        '[class*="modal"]'
      ];
      for (const i of s)
        if (e = document.querySelector(i), e && (o = e.querySelector(this.config.footerSelector) || e.querySelector(".footer") || e.querySelector('[class*="footer"]'), o))
          break;
    }
    if (!e || !o) {
      this.state.retryCount < this.config.maxRetries && (this.state.retryCount++, setTimeout(() => this.createButton(), this.config.retryInterval));
      return;
    }
    const r = document.createElement("button");
    r.id = this.config.buttonId, r.title = this.config.stateTitleMap[this.state.currentState], r.style.cssText = `
      font-family: var(--orca-fontfamily-fallback, -apple-system, BlinkMacSystemFont);
      font-weight: var(--orca-fontweight-md, 400);
      line-height: var(--orca-lineheight-md, 1.6);
      font-size: 13px;
      color: var(--orca-color-text-2, #666);
      box-sizing: border-box;
      outline: none;
      margin: 0;
      margin-right: 16px;
      cursor: pointer;
      padding: 0;
      border: none;
      border-radius: var(--orca-radius-sm, 4px);
      transition: all 0.2s ease;
      display: inline-flex;
      align-items: center;
      gap: 4px;
      height: auto;
      width: auto;
    `, r.innerHTML = `${this.getButtonSvg()}<span>${this.config.stateTextMap[this.state.currentState]}</span>`, r.addEventListener("click", () => this.toggleTripleState()), o.appendChild(r), this.state.retryCount = 0, this.updateBlocksDisplay(), this.updateButtonStyle();
  }
  /**
   * 获取按钮SVG图标
   */
  getButtonSvg() {
    switch (this.state.currentState) {
      case 1:
        return `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M22 12H2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>`;
      case 2:
        return `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M12 7V12L16 14" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>`;
      default:
        return `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>`;
    }
  }
  /**
   * 更新按钮样式
   */
  updateButtonStyle() {
    const t = document.getElementById(this.config.buttonId);
    if (t)
      switch (t.title = this.config.stateTitleMap[this.state.currentState], t.innerHTML = `${this.getButtonSvg()}<span>${this.config.stateTextMap[this.state.currentState]}</span>`, this.state.currentState) {
        case 1:
          t.style.backgroundColor = "var(--orca-color-warning-1, rgba(214, 156, 20, 0.15))", t.style.color = "var(--orca-color-warning-5, rgb(214, 156, 20))";
          break;
        case 2:
          t.style.backgroundColor = "var(--orca-color-primary-1, rgba(24, 124, 201, 0.15))", t.style.color = "var(--orca-color-primary-5, #187cc9)";
          break;
        default:
          t.style.backgroundColor = "transparent", t.style.color = "var(--orca-color-text-2, #666)";
          break;
      }
  }
  /**
   * 设置主观察者
   */
  setupMainObserver() {
    this.state.mainObserver = new MutationObserver((t) => {
      const e = document.getElementById(this.config.buttonId);
      let o = document.querySelector(this.config.containerSelector), r = null;
      if (o)
        r = o.querySelector(this.config.footerSelector);
      else {
        const s = [
          ".orca-menu",
          ".search-modal",
          ".modal",
          '[class*="search"]',
          '[class*="modal"]'
        ];
        for (const i of s)
          if (o = document.querySelector(i), o && (r = o.querySelector(this.config.footerSelector) || o.querySelector(".footer") || o.querySelector('[class*="footer"]'), r))
            break;
      }
      o && r && (!e || !r.contains(e)) && this.createButton(), this.state.currentState !== 0 && this.updateBlocksDisplay();
    }), this.state.mainObserver.observe(document.body, {
      childList: !0,
      subtree: !0,
      attributes: !0,
      attributeFilter: ["class", "style"]
    });
  }
}
class It {
  constructor(t, e) {
    a(this, "plugins", /* @__PURE__ */ new Map());
    a(this, "pluginInstances", /* @__PURE__ */ new Map());
    a(this, "buttonManager", null);
    a(this, "pluginName", "");
    this.buttonManager = t || null, this.pluginName = e || "";
  }
  /**
   * 注册插件
   */
  register(t, e, o) {
    if (this.pluginInstances.has(t))
      return this.pluginInstances.get(t);
    const r = new e(this.buttonManager || void 0, this.pluginName);
    if (this.plugins.set(t, e), this.pluginInstances.set(t, r), r && typeof r.initialize == "function") {
      const s = r.initialize();
      s instanceof Promise && s.catch((i) => {
        console.error(`插件 ${t} 初始化失败:`, i);
      });
    }
    return r;
  }
  /**
   * 卸载所有插件
   */
  unloadAll() {
    this.pluginInstances.forEach((t, e) => {
      t && typeof t.destroy == "function" && t.destroy();
    }), this.pluginInstances.clear(), this.plugins.clear();
  }
  /**
   * 获取插件实例
   */
  getPlugin(t) {
    return this.pluginInstances.get(t) || null;
  }
  /**
   * 检查插件是否存在
   */
  hasPlugin(t) {
    return this.pluginInstances.has(t);
  }
}
let T, g, E;
async function Bt(n) {
  T = n, orca.state.locale, orca.themes.register(T, "W95", "css/theme.css"), E = new dt(
    c.retryInterval,
    c.maxRetries,
    c.toolbarSelector,
    c.targetPanelSelector
  ), g = new It(E, T), g.register("queryViewToggle", et, 1), g.register("headingNumberToggle", rt, 2), g.register("propsToggle", it, 3), g.register("queryBlockRefToggle", st, 4), g.register("queryBlockHighlightToggle", mt, 5), g.register("mirrorContainerToggle", pt, 6), g.register("listBreadcrumbToggle", bt, 7), g.register("cardViewMinimalToggle", yt, 8), g.register("cardCoverAspectRatioToggle", ft, 9), g.register("queryListBlockCreationTime", St, 10), g.register("theme2Toggle", vt, 11), g.register("ocrImageBlockToggle", wt, 12), E.initialize();
}
async function Et() {
  g && g.unloadAll(), E && E.destroy(), orca.themes.unregister("W95");
}
export {
  Bt as load,
  Et as unload
};
